# Lab 1: Dual-Issue RV32I Microprocessor with Microcode Engine

**Course**: Advanced Computer Architecture (CityU EE5607)
**Instructor**: Prof. Zhangxi Tan (RIOS Laboratory)
**Released**: Week 3 | **Due**: Week 5 (2-week lab)

---

## Quick Start

```bash
# 1. Build the C performance model
make model

# 2. Build test programs (requires RISC-V GCC toolchain)
make tests

# 3. Run the C model on a test
./perf_model/rv32_sim --stats tests/bin/test_alu_basic.bin

# 4. After completing Part C (RTL), run co-simulation
make cosim RTL_DIR=submission/part_c/rtl TEST=test_alu_basic

# 5. Run all co-simulation tests
make cosim-all RTL_DIR=submission/part_c/rtl
```

## Directory Structure

```
release/
├── docs/
│   └── lab1_handout.md        ← READ THIS FIRST
├── perf_model/                ← C performance model (Part B)
│   ├── cpu_model.h            (DO NOT MODIFY)
│   ├── cpu_model.c            (COMPLETE THE TODOs)
│   ├── microcode_rom.h        (DO NOT MODIFY)
│   ├── microcode_rom.c        (COMPLETE DIV MICROCODE)
│   ├── main.c                 (DO NOT MODIFY)
│   ├── elf_loader.c/h         (DO NOT MODIFY)
│   └── Makefile
├── sim/                       ← Co-simulation framework (Part C)
│   ├── cosim_tb.cpp           (DO NOT MODIFY)
│   ├── cosim_checker.h        (DO NOT MODIFY)
│   ├── cosim_dpi.sv
│   └── Makefile
├── tests/                     ← Test programs
│   ├── asm/*.S                (Assembly test sources)
│   ├── bin/                   (Pre-compiled binaries — after make tests)
│   └── common/                (Startup code, linker script)
├── rtl_stub/                  ← RTL starting point (Part C)
│   ├── rv32_pkg.sv            (Shared type definitions)
│   ├── rv32_top.sv            (Top-level interface — do not change ports)
│   └── README.md
├── submission_template/       ← Copy this for your submission
└── Makefile                   ← Top-level build
```

## Required Tools

| Tool | Install (macOS) | Install (Ubuntu) |
|:---|:---|:---|
| RISC-V GCC | `brew install riscv-gnu-toolchain` | `apt install gcc-riscv64-unknown-elf` |
| Verilator 5.x | `brew install verilator` | [Build from source](https://verilator.org) |
| Yosys (optional) | `brew install yosys` | `apt install yosys` |
| GCC/Clang | Pre-installed | `apt install gcc` |

## Full Assignment

See [`docs/lab1_handout.md`](docs/lab1_handout.md) for the complete assignment specification.
