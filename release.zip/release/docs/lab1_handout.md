# Lab 1: Dual-Issue RV32I Microprocessor with Microcode Engine

**Course**: Advanced Computer Architecture (CityU EE5607)
**Instructor**: Prof. Zhangxi Tan (RIOS Laboratory)
**Released**: Week 3 | **Due**: Week 5 (2-week lab)
**Total Points**: 100 (+ 10 optional extra credit)

---

## 1. Overview & Learning Objectives

In this lab, you will design, model, and verify a **dual-issue, in-order, 5-stage pipelined RV32I microprocessor** with a **microcode engine** for complex instruction execution. This lab integrates the foundational concepts from Weeks 1–3 of the course:

- **Week 1**: Quantitative Principles — Iron Law of Processor Performance, Amdahl's Law
- **Week 2**: ISA Philosophy, Microprogramming, Single-Bus Microcoded Engines
- **Week 3**: Classical Pipelining, Hazard Detection/Resolution, Precise Exceptions

### What You Will Do

| Part | Weight | Description |
|:---|:---:|:---|
| **Part A** | 20% | Back-of-the-envelope quantitative analysis (CPI, Amdahl's Law, AMAT) |
| **Part B** | 40% | Build a cycle-accurate C performance model of the dual-issue pipeline |
| **Part C** | 30% | Use an LLM to generate SystemVerilog RTL and run lock-step co-simulation |
| **Part D** | 10% *(extra credit)* | Synthesize RTL with Yosys and report area/timing |

### Target Microarchitecture

```
                         ┌─────────────────────────────────────────────────────┐
                         │              Dual-Issue In-Order Pipeline            │
                         │                                                     │
  ┌──────────┐  2 insns  │  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐ │
  │ I-Memory │──────────►│  │  IF  │─►│  ID  │─►│  EX  │─►│ MEM  │─►│  WB  │ │
  │ (aligned │  /cycle   │  │      │  │      │  │      │  │      │  │      │ │
  │  64-bit) │           │  │Slot 0│  │Slot 0│  │ALU 0 │  │LD/ST │  │WB  0 │ │
  └──────────┘           │  │Slot 1│  │Slot 1│  │ALU 1 │  │      │  │WB  1 │ │
                         │  └──┬───┘  └──┬───┘  └──────┘  └──────┘  └──────┘ │
                         │     │         │                                     │
                         │     │    ┌────▼────┐                                │
                         │     │    │Microcode│  Complex ops (MUL, DIV, CSR)   │
                         │     │    │ Engine  │  trap into µcode sequences     │
                         │     │    │(ROM+µPC)│                                │
                         │     │    └─────────┘                                │
                         │     │                                               │
                         │  ┌──▼──────────────────────────────────────────┐    │
                         │  │  Hazard Detection & Forwarding Network     │    │
                         │  └─────────────────────────────────────────────┘    │
                         └─────────────────────────────────────────────────────┘
```

**Key architectural features**:
- **5-stage pipeline**: IF → ID → EX → MEM → WB
- **Dual-issue, in-order**: Up to 2 instructions fetched, decoded, and issued per cycle (aligned 64-bit fetch)
- **Microcode engine**: Complex operations (MUL, DIV, CSR read-modify-write) trap into a microcode ROM that emits micro-operations (µops) sequentially
- **Forwarding network**: EX→EX, MEM→EX bypasses to minimize data hazard stalls
- **Single memory port**: Only one load/store can access D-memory per cycle (structural hazard if both slots need memory)

---

## 2. Part A: Quantitative Analysis (20 points)

Answer the following questions in `submission/part_a/analysis.md`. Show all work.

### Question A.1: Iron Law CPI Analysis (5 points)

Consider the following RV32I instruction mix for a typical integer workload:

| Instruction Class | Frequency | Base CPI (Single-Issue) | Dual-Issue CPI (Ideal) |
|:---|:---:|:---:|:---:|
| ALU (ADD, SUB, AND, OR, XOR, SLT, shifts) | 40% | 1 | 0.5 |
| Load (LW, LB, LH) | 20% | 1 | 1.0 (memory port conflict) |
| Store (SW, SB, SH) | 10% | 1 | 1.0 (memory port conflict) |
| Branch (BEQ, BNE, etc.) | 20% | 1 | 1.0 (only slot 0) |
| MUL (via microcode, 8 µops) | 5% | 8 | 8.0 (serialized) |
| DIV (via microcode, 34 µops) | 5% | 34 | 34.0 (serialized) |

**(a)** Calculate the weighted average CPI for the **single-issue** pipeline (no dual-issue, no stalls other than microcode).

**(b)** Calculate the weighted average CPI for the **dual-issue** pipeline under ideal conditions (no data hazards, only structural constraints listed above).

**(c)** What is the speedup of dual-issue over single-issue? How does this compare to the theoretical maximum of 2×? Explain why the speedup is less than 2×.

### Question A.2: Amdahl's Law and Microcode (5 points)

Your dual-issue processor spends 10% of execution time in the microcode engine (processing MUL/DIV). An engineer proposes adding a hardwired single-cycle multiplier to the EX stage, which would eliminate all MUL microcode overhead (MUL becomes CPI=1).

**(a)** Using Amdahl's Law, what is the maximum speedup from this enhancement?

**(b)** If the hardwired multiplier increases the critical path by 15% (i.e., clock period increases by 15%), is the enhancement still worth it? Calculate the net speedup.

**(c)** Now suppose the engineer also proposes a 4-cycle pipelined divider (instead of the 34-µop microcode sequence). The remaining microcode fraction drops to 1%. Combined with the single-cycle multiplier, what is the total speedup?

### Question A.3: Pipeline Hazard Stall Analysis (5 points)

Consider the following code sequence running on your dual-issue pipeline:

```asm
    ADD  x1, x2, x3      # Slot 0, Cycle 1
    SUB  x4, x1, x5      # Slot 1, Cycle 1 — can this issue with ADD? Explain.
    LW   x6, 0(x1)       # Slot 0, Cycle 2
    AND  x7, x6, x8      # Slot 1, Cycle 2 — can this issue with LW? Explain.
    BEQ  x7, x0, target  # Slot 0, Cycle 3
    OR   x9, x10, x11    # Slot 1, Cycle 3 — can this issue with BEQ? Explain.
```

**(a)** For each cycle, determine which instructions can actually co-issue in the dual-issue pipeline. Assume full forwarding is available (EX→EX, MEM→EX). State any stall cycles.

**(b)** Calculate the actual CPI for this code sequence.

### Question A.4: AMAT and Memory Hierarchy (5 points)

Your dual-issue processor has the following memory parameters:

| Parameter | Value |
|:---|:---|
| L1 I-Cache hit time | 1 cycle |
| L1 D-Cache hit time | 1 cycle |
| L1 I-Cache miss rate | 2% |
| L1 D-Cache miss rate | 8% |
| L2 Unified Cache hit time | 10 cycles |
| L2 Miss rate (local) | 20% |
| Main memory access time | 100 cycles |

**(a)** Calculate the AMAT for instruction fetches.

**(b)** Calculate the AMAT for data accesses.

**(c)** If 30% of instructions are loads/stores, what is the effective average memory access penalty per instruction (combining I-cache and D-cache)?

---

## 3. Part B: C Performance Model (40 points)

### 3.1 Overview

You will complete a **cycle-accurate C performance model** of the dual-issue RV32I pipeline. The skeleton code is provided in `perf_model/` with TODO markers where you must add your implementation.

The model must:
1. Accurately decode and execute all RV32I base instructions
2. Implement dual-issue logic with correct hazard detection
3. Model the microcode engine for MUL, DIV, and CSR operations
4. Track performance counters (cycles, instructions retired, stall breakdown)
5. Export per-cycle architectural state snapshots for co-simulation (Part C)

### 3.2 Files to Modify

| File | What to do |
|:---|:---|
| `perf_model/cpu_model.c` | **Complete all TODO sections**: `fetch_dual()`, `decode_dual()`, `execute_dual()`, `memory_stage()`, `writeback_dual()`, `hazard_detect()`, `microcode_dispatch()` |
| `perf_model/microcode_rom.c` | **Complete the DIV microcode sequence** (MUL is provided as reference) |

### 3.3 Do NOT Modify

| File | Reason |
|:---|:---|
| `perf_model/cpu_model.h` | Data structures are fixed for co-sim compatibility |
| `perf_model/main.c` | Driver is fixed for autograder compatibility |
| `perf_model/elf_loader.c/h` | ELF loading is provided |
| `perf_model/microcode_rom.h` | Microcode format is fixed |

### 3.4 Dual-Issue Rules

Your implementation must enforce these issue constraints:

1. **Slot 0** can issue any instruction type (ALU, branch, load, store, microcode-trapped)
2. **Slot 1** can issue only ALU instructions (no branches, loads, stores, or microcode-trapped ops)
3. **RAW dependency**: If Slot 1's source register matches Slot 0's destination register *in the same cycle*, Slot 1 must stall (becomes a bubble)
4. **Structural hazard**: Only one memory access per cycle (Slot 0 has priority)
5. **Microcode trap**: When a microcode-trapped instruction is in Slot 0, Slot 1 is squashed; the pipeline drains and the microcode engine takes over until the sequence completes
6. **Branch in Slot 0**: When a branch is in Slot 0, Slot 1 can still issue if no data dependency; if the branch is taken, Slot 1 is flushed

### 3.5 Microcode Engine Specification

The microcode engine activates when the decoder encounters an instruction that requires micro-sequencing:

| Instruction | Trigger | Microcode Length | Description |
|:---|:---|:---:|:---|
| `MUL rd, rs1, rs2` | opcode=0x33, funct3=0x0, funct7=0x01 | 8 µops | Shift-and-add multiplication |
| `MULH rd, rs1, rs2` | opcode=0x33, funct3=0x1, funct7=0x01 | 10 µops | Signed high multiplication |
| `DIV rd, rs1, rs2` | opcode=0x33, funct3=0x4, funct7=0x01 | 34 µops | Restoring division |
| `REM rd, rs1, rs2` | opcode=0x33, funct3=0x6, funct7=0x01 | 34 µops | Remainder (reuse DIV logic) |
| `CSRRW`, `CSRRS`, `CSRRC` | opcode=0x73 | 3 µops | CSR read-modify-write |

When activated:
1. Pipeline stalls (no new instructions fetched)
2. Microcode ROM is addressed by µPC starting at the entry point for the trapped instruction
3. Each µop executes in one cycle through the EX stage
4. On final µop, result is written back and normal fetch resumes

### 3.6 Performance Counters

Your model must track and report:

```
=== Performance Summary ===
Total Cycles:          XXXX
Instructions Retired:  XXXX
CPI:                   X.XX
Dual-Issue Rate:       XX.X%  (cycles where 2 insns retired / total active cycles)
Stall Breakdown:
  RAW Hazard Stalls:   XXXX cycles
  Load-Use Stalls:     XXXX cycles
  Branch Stalls:       XXXX cycles
  Structural Stalls:   XXXX cycles
  Microcode Cycles:    XXXX cycles
```

### 3.7 Building and Testing

```bash
cd perf_model/
make                          # Build the C model
./rv32_sim tests/bin/test_alu_basic.bin    # Run a test
./rv32_sim --stats tests/bin/test_fibonacci.bin  # Run with performance stats
./rv32_sim --cosim tests/bin/test_alu_basic.bin  # Output co-sim state trace
```

### 3.8 Grading Criteria (40 points)

| Criterion | Points |
|:---|:---:|
| All RV32I instructions execute correctly (9 test programs pass) | 15 |
| Dual-issue logic correct (proper co-issue and stall detection) | 8 |
| Microcode engine functional (MUL, DIV produce correct results) | 7 |
| Performance counters accurate (CPI within ±5% of reference) | 5 |
| Code quality (clean, readable, commented) | 5 |

---

## 4. Part C: RTL Implementation & Co-Simulation (30 points)

### 4.1 Overview

Using an **LLM of your choice** (ChatGPT, Claude, Gemini, Copilot, local models, etc.), generate a **SystemVerilog implementation** of the dual-issue RV32I pipeline. Then use the provided Verilator co-simulation testbench to verify your RTL against your C model in **lock-step mode**.

### 4.2 RTL Requirements

Your RTL must:
1. Implement the same microarchitecture as the C model (5-stage, dual-issue, microcode engine)
2. Have a top-level module named `rv32_top` matching the interface in `rtl_stub/rv32_top.sv`
3. Synthesize cleanly with Verilator (no `%Error`, no undriven signals)
4. Pass lock-step co-simulation on all 9 test programs

### 4.3 Workflow

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  1. Study your   │     │  2. Prompt LLM   │     │  3. Iterate:     │
│  C model + spec  │────►│  to generate     │────►│  fix errors,     │
│  (Part B)        │     │  SystemVerilog   │     │  re-prompt LLM   │
└──────────────────┘     └──────────────────┘     └────────┬─────────┘
                                                           │
                         ┌──────────────────┐              │
                         │  4. Run co-sim   │◄─────────────┘
                         │  make cosim      │
                         │  Check pass/fail │
                         └──────────────────┘
```

### 4.4 Using the Co-Simulation Testbench

```bash
# Place your .sv files in submission/part_c/rtl/
cd sim/
make cosim RTL_DIR=../submission/part_c/rtl TEST=test_alu_basic
# Runs: Verilator compile → link with C model → lock-step execution
# Output: PASS/FAIL with cycle count and mismatch details

make cosim-all RTL_DIR=../submission/part_c/rtl
# Runs all 9 test programs
```

The co-simulation testbench compares **every cycle**:
- All 32 GPR values (`x0`–`x31`)
- Program Counter (PC)
- Instructions retired this cycle
- Microcode engine state (active/idle, µPC)

On mismatch, it dumps:
```
COSIM MISMATCH at cycle 147:
  C Model:  PC=0x00000234  x5=0x0000001A  x6=0x00000003
  RTL:      PC=0x00000234  x5=0x0000001A  x6=0x00000005  ← MISMATCH
  Instruction: AND x6, x5, x8
```

### 4.5 Documenting Your LLM Usage

In `submission/part_c/llm_prompts.md`, document:
1. Which LLM(s) you used and version/model name
2. Key prompts that produced working code (copy-paste the prompt text)
3. How many iterations it took to get passing co-simulation
4. What types of bugs the LLM introduced and how you fixed them
5. Your assessment: what the LLM did well, what it struggled with

> **This is a learning exercise**: We are interested in understanding how LLMs perform as RTL generation tools. There is no penalty for using any particular LLM or for needing many iterations. Honest, detailed documentation earns full marks.

### 4.6 Grading Criteria (30 points)

| Criterion | Points |
|:---|:---:|
| RTL compiles with Verilator (no errors) | 5 |
| Co-simulation passes on basic tests (ALU, load/store, branch) | 10 |
| Co-simulation passes on hazard and microcode tests | 8 |
| Co-simulation passes on mixed workload / Fibonacci | 4 |
| LLM usage documentation (prompts, iterations, analysis) | 3 |

---

## 5. Part D: Logic Synthesis with Yosys (10 points — Extra Credit)

### 5.1 Overview

Synthesize your SystemVerilog RTL using **Yosys** (open-source synthesis tool) and report area, timing estimates, and critical path.

### 5.2 Steps

```bash
# Install Yosys (if not already available)
# On macOS: brew install yosys
# On Ubuntu: sudo apt install yosys

cd submission/part_d/
# Edit yosys_script.ys with your RTL file paths, then:
yosys yosys_script.ys | tee synth_report.txt
```

A template `yosys_script.ys` is provided in the submission template.

### 5.3 What to Report

In `submission/part_d/synth_report.txt`, include:
1. Gate count (total cells after mapping)
2. Estimated area (if using a cell library)
3. Critical path analysis (longest combinational path)
4. Which pipeline stage dominates the critical path
5. Any synthesis warnings or unmapped cells

### 5.4 Grading Criteria (10 points extra credit)

| Criterion | Points |
|:---|:---:|
| RTL synthesizes without errors in Yosys | 4 |
| Synthesis report includes gate count and critical path | 3 |
| Thoughtful analysis comparing synthesis results to back-of-envelope estimates | 3 |

---

## 6. Submission Instructions

### 6.1 Submission Format

Copy the `submission_template/` directory, rename it to `<student_id>_lab1/`, and fill in all parts:

```
<student_id>_lab1/
├── README.md              # Your name, student ID, AI tools declaration
├── part_a/
│   └── analysis.md        # Written answers (show all work)
├── part_b/
│   ├── cpu_model.c         # Your completed C model
│   ├── cpu_model.h         # (only if modified — explain why)
│   ├── microcode_rom.c     # Your completed microcode ROM
│   └── Makefile
├── part_c/
│   ├── rtl/
│   │   └── *.sv            # Your LLM-generated SystemVerilog files
│   ├── llm_prompts.md      # LLM usage documentation
│   └── cosim_log.txt       # Co-simulation output log
├── part_d/                 # (Optional extra credit)
│   ├── yosys_script.ys
│   └── synth_report.txt
└── perf_report.md          # Performance analysis: CPI breakdown, dual-issue rate, analysis
```

### 6.2 Submission Checklist

- [ ] `README.md` filled with name, ID, and AI tools used
- [ ] Part A: All 4 questions answered with work shown
- [ ] Part B: `cpu_model.c` and `microcode_rom.c` completed; `make` succeeds; all tests pass
- [ ] Part C: RTL files in `rtl/`; `llm_prompts.md` filled; `cosim_log.txt` showing test results
- [ ] Part D (optional): `synth_report.txt` with analysis
- [ ] `perf_report.md`: Performance summary with CPI, dual-issue rate, stall breakdown

### 6.3 Deadline

**Due: Week 5, Saturday 23:59 HKT** (2 weeks from release)

Late submissions: −10 points per 24-hour period, up to 3 days. No submissions accepted after 72 hours.

### 6.4 Academic Integrity

- You **must** use LLM tools for Part C (RTL generation). This is a requirement, not a violation.
- You **may** use LLM tools to help with Part B (C model), but you must understand every line of code you submit.
- You **must not** copy another student's C model or RTL.
- You **must** document all LLM usage honestly in `llm_prompts.md`.
- Submissions will be checked for inter-student similarity using automated tools.

---

## 7. Tool Setup

### Required Tools

| Tool | Version | Purpose | Install |
|:---|:---|:---|:---|
| RISC-V GCC Toolchain | 13.x+ | Compile test programs | `brew install riscv-gnu-toolchain` or [prebuilt](https://github.com/riscv-collab/riscv-gnu-toolchain) |
| Verilator | 5.x+ | RTL simulation & co-sim | `brew install verilator` or [build from source](https://verilator.org/guide/latest/install.html) |
| Yosys *(optional)* | 0.40+ | Logic synthesis | `brew install yosys` or [build from source](https://github.com/YosysHQ/yosys) |
| GNU Make | 4.x+ | Build system | Pre-installed on most systems |
| GCC/Clang | 13.x+ | Build C model | Pre-installed on most systems |

### Quick Test

```bash
# Verify tools are installed:
riscv64-unknown-elf-gcc --version
verilator --version
yosys --version  # optional

# Build and run the C model (even with TODOs, it should compile):
cd perf_model/ && make && echo "Build OK"
```

---

## 8. Suggested 2-Week Timeline

| Day | Task |
|:---|:---|
| **Days 1–2** | Read handout, set up tools, complete Part A (pen-and-paper) |
| **Days 3–5** | Study C model skeleton, implement `fetch_dual()`, `decode_dual()`, `hazard_detect()` |
| **Days 6–7** | Implement `execute_dual()`, `memory_stage()`, `writeback_dual()`, basic tests passing |
| **Days 8–9** | Implement `microcode_dispatch()`, complete microcode ROM, all Part B tests passing |
| **Day 10** | Begin Part C: prompt LLM for RTL, iterate on compilation errors |
| **Days 11–12** | Debug RTL co-simulation mismatches, iterate with LLM |
| **Day 13** | All co-sim tests passing; write `llm_prompts.md` and `perf_report.md` |
| **Day 14** | (Optional) Part D: Yosys synthesis. Final review and submission |

---

*Good luck! This lab is designed to be ambitious but achievable with AI assistance. Start early, iterate often, and document your process.*
