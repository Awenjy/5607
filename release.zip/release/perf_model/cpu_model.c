/*
 * cpu_model.c — Dual-Issue RV32I Performance Model Implementation
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 *
 * Students: Complete all functions marked with TODO.
 * Do NOT modify function signatures — co-simulation depends on them.
 */

#include "cpu_model.h"
#include "microcode_rom.h"
#include <string.h>
#include <stdlib.h>
#include <assert.h>

/* ========================================================================
 * Internal Helpers (provided — do not modify)
 * ======================================================================== */

static inline uint32_t sign_extend(uint32_t val, int bits) {
    uint32_t mask = 1U << (bits - 1);
    return (val ^ mask) - mask;
}

static inline void write_reg(rv32_cpu_state_t *cpu, uint8_t rd, uint32_t val) {
    if (rd != 0) {  /* x0 is hardwired to zero */
        cpu->regs[rd] = val;
    }
}

static inline uint32_t read_reg(const rv32_cpu_state_t *cpu, uint8_t rs) {
    return cpu->regs[rs];  /* x0 always returns 0 */
}

/* ========================================================================
 * Memory Access Helpers (provided — do not modify)
 * ======================================================================== */

uint32_t mem_read_word(const rv32_cpu_state_t *cpu, uint32_t addr) {
    assert(addr + 3 < MEMORY_SIZE);
    return (uint32_t)cpu->memory[addr]
         | ((uint32_t)cpu->memory[addr + 1] << 8)
         | ((uint32_t)cpu->memory[addr + 2] << 16)
         | ((uint32_t)cpu->memory[addr + 3] << 24);
}

uint16_t mem_read_half(const rv32_cpu_state_t *cpu, uint32_t addr) {
    assert(addr + 1 < MEMORY_SIZE);
    return (uint16_t)cpu->memory[addr]
         | ((uint16_t)cpu->memory[addr + 1] << 8);
}

uint8_t mem_read_byte(const rv32_cpu_state_t *cpu, uint32_t addr) {
    assert(addr < MEMORY_SIZE);
    return cpu->memory[addr];
}

void mem_write_word(rv32_cpu_state_t *cpu, uint32_t addr, uint32_t val) {
    assert(addr + 3 < MEMORY_SIZE);
    cpu->memory[addr]     = (uint8_t)(val & 0xFF);
    cpu->memory[addr + 1] = (uint8_t)((val >> 8) & 0xFF);
    cpu->memory[addr + 2] = (uint8_t)((val >> 16) & 0xFF);
    cpu->memory[addr + 3] = (uint8_t)((val >> 24) & 0xFF);
}

void mem_write_half(rv32_cpu_state_t *cpu, uint32_t addr, uint16_t val) {
    assert(addr + 1 < MEMORY_SIZE);
    cpu->memory[addr]     = (uint8_t)(val & 0xFF);
    cpu->memory[addr + 1] = (uint8_t)((val >> 8) & 0xFF);
}

void mem_write_byte(rv32_cpu_state_t *cpu, uint32_t addr, uint8_t val) {
    assert(addr < MEMORY_SIZE);
    cpu->memory[addr] = val;
}

/* ========================================================================
 * Lifecycle (provided — do not modify)
 * ======================================================================== */

void cpu_init(rv32_cpu_state_t *cpu) {
    memset(cpu, 0, sizeof(rv32_cpu_state_t));
    cpu->halted = false;
    cpu->cosim_enabled = false;
    cpu->cosim_trace_fp = NULL;
    microcode_rom_init();
}

void cpu_reset(rv32_cpu_state_t *cpu, uint32_t entry_pc) {
    cpu->pc = entry_pc;
    memset(cpu->regs, 0, sizeof(cpu->regs));
    cpu->regs[2] = MEMORY_SIZE - 4;  /* sp = top of memory */
    cpu->halted = false;
    cpu->stall_if = false;
    cpu->stall_id = false;
    cpu->flush_pipeline = false;
    memset(&cpu->perf, 0, sizeof(perf_counters_t));
    memset(&cpu->microcode, 0, sizeof(microcode_engine_t));

    /* Clear pipeline registers */
    memset(&cpu->if_id, 0, sizeof(pipeline_reg_t));
    memset(&cpu->id_ex, 0, sizeof(pipeline_reg_t));
    memset(&cpu->ex_mem, 0, sizeof(pipeline_reg_t));
    memset(&cpu->mem_wb, 0, sizeof(pipeline_reg_t));
}

void cpu_load_program(rv32_cpu_state_t *cpu, const uint8_t *program,
                      uint32_t size, uint32_t load_addr) {
    assert(load_addr + size <= MEMORY_SIZE);
    memcpy(&cpu->memory[load_addr], program, size);
}

bool cpu_is_halted(const rv32_cpu_state_t *cpu) {
    return cpu->halted;
}

/* ========================================================================
 * Instruction Decode (provided — do not modify)
 *
 * This function decodes a raw 32-bit instruction into a decoded_insn_t.
 * It extracts all fields, classifies the instruction type, determines
 * register usage, and detects microcode-trapped operations.
 * ======================================================================== */

decoded_insn_t decode_instruction(uint32_t raw, uint32_t pc) {
    decoded_insn_t d;
    memset(&d, 0, sizeof(decoded_insn_t));

    d.raw = raw;
    d.pc  = pc;
    d.valid = true;
    d.needs_microcode = false;

    /* Extract fields */
    d.opcode = raw & 0x7F;
    d.rd     = (raw >> 7) & 0x1F;
    d.funct3 = (raw >> 12) & 0x07;
    d.rs1    = (raw >> 15) & 0x1F;
    d.rs2    = (raw >> 20) & 0x1F;
    d.funct7 = (raw >> 25) & 0x7F;

    switch (d.opcode) {
    case OP_LUI:
        d.type = INSN_TYPE_LUI;
        d.imm = raw & 0xFFFFF000;
        d.writes_rd = true;
        break;

    case OP_AUIPC:
        d.type = INSN_TYPE_AUIPC;
        d.imm = raw & 0xFFFFF000;
        d.writes_rd = true;
        break;

    case OP_JAL:
        d.type = INSN_TYPE_JAL;
        d.imm = (int32_t)(
            (((raw >> 31) & 1) << 20) |
            (((raw >> 12) & 0xFF) << 12) |
            (((raw >> 20) & 1) << 11) |
            (((raw >> 21) & 0x3FF) << 1)
        );
        d.imm = sign_extend(d.imm, 21);
        d.writes_rd = true;
        break;

    case OP_JALR:
        d.type = INSN_TYPE_JALR;
        d.imm = sign_extend(raw >> 20, 12);
        d.uses_rs1 = true;
        d.writes_rd = true;
        break;

    case OP_BRANCH:
        d.type = INSN_TYPE_BRANCH;
        d.imm = (int32_t)(
            (((raw >> 31) & 1) << 12) |
            (((raw >> 7) & 1) << 11) |
            (((raw >> 25) & 0x3F) << 5) |
            (((raw >> 8) & 0xF) << 1)
        );
        d.imm = sign_extend(d.imm, 13);
        d.uses_rs1 = true;
        d.uses_rs2 = true;
        break;

    case OP_LOAD:
        d.type = INSN_TYPE_LOAD;
        d.imm = sign_extend(raw >> 20, 12);
        d.uses_rs1 = true;
        d.writes_rd = true;
        break;

    case OP_STORE:
        d.type = INSN_TYPE_STORE;
        d.imm = sign_extend(
            (((raw >> 25) & 0x7F) << 5) | ((raw >> 7) & 0x1F), 12);
        d.uses_rs1 = true;
        d.uses_rs2 = true;
        break;

    case OP_OP_IMM:
        d.type = INSN_TYPE_ALU;
        d.imm = sign_extend(raw >> 20, 12);
        d.uses_rs1 = true;
        d.writes_rd = true;
        break;

    case OP_OP:
        if (d.funct7 == F7_MULDIV) {
            /* M extension — trap to microcode */
            d.type = INSN_TYPE_MICROCODE;
            d.needs_microcode = true;
            d.uses_rs1 = true;
            d.uses_rs2 = true;
            d.writes_rd = true;
            /* Microcode entry point looked up during dispatch */
        } else {
            d.type = INSN_TYPE_ALU;
            d.uses_rs1 = true;
            d.uses_rs2 = true;
            d.writes_rd = true;
        }
        break;

    case OP_MISC_MEM:
        d.type = INSN_TYPE_FENCE;
        break;

    case OP_SYSTEM:
        if (d.funct3 == 0) {
            /* ECALL / EBREAK */
            d.type = INSN_TYPE_SYSTEM;
        } else {
            /* CSR instructions — trap to microcode */
            d.type = INSN_TYPE_MICROCODE;
            d.needs_microcode = true;
            d.uses_rs1 = (d.funct3 <= 3); /* CSRRW/S/C use rs1 */
            d.writes_rd = true;
        }
        break;

    default:
        d.type = INSN_TYPE_INVALID;
        d.valid = false;
        break;
    }

    /* NOP detection: ADDI x0, x0, 0 */
    if (raw == 0x00000013) {
        d.type = INSN_TYPE_NOP;
    }

    return d;
}

/* ========================================================================
 * Forwarding Logic (provided — do not modify)
 *
 * Check forwarding network for a given source register.
 * Returns true if forwarding is available, and writes the forwarded
 * value to *out_val.
 * ======================================================================== */

static bool check_forward(const rv32_cpu_state_t *cpu, uint8_t rs,
                          uint32_t *out_val) {
    /* Priority: EX/MEM has newer value than MEM/WB */
    for (int slot = 0; slot < NUM_ISSUE_SLOTS; slot++) {
        if (cpu->fwd_ex_mem[slot].valid && cpu->fwd_ex_mem[slot].rd == rs && rs != 0) {
            *out_val = cpu->fwd_ex_mem[slot].value;
            return true;
        }
    }
    for (int slot = 0; slot < NUM_ISSUE_SLOTS; slot++) {
        if (cpu->fwd_mem_wb[slot].valid && cpu->fwd_mem_wb[slot].rd == rs && rs != 0) {
            *out_val = cpu->fwd_mem_wb[slot].value;
            return true;
        }
    }
    return false;
}

/* Read a source register value, using forwarding if available */
static uint32_t read_with_forward(const rv32_cpu_state_t *cpu, uint8_t rs) {
    uint32_t val;
    if (check_forward(cpu, rs, &val)) {
        return val;
    }
    return read_reg(cpu, rs);
}

/* ========================================================================
 * Co-Simulation (provided — do not modify)
 * ======================================================================== */

void cosim_snapshot(rv32_cpu_state_t *cpu, cosim_checkpoint_t *cp) {
    cp->cycle = cpu->perf.cycles;
    cp->pc = cpu->pc;
    memcpy(cp->regs, cpu->regs, sizeof(cpu->regs));
    cp->microcode_active = cpu->microcode.active;
    cp->upc = cpu->microcode.upc;

    /* Count instructions retired this cycle */
    cp->insns_retired_this_cycle = 0;
    for (int s = 0; s < NUM_ISSUE_SLOTS; s++) {
        if (cpu->mem_wb.valid[s] && cpu->mem_wb.insn[s].valid) {
            cp->insns_retired_this_cycle++;
        }
    }
}

void cosim_emit_checkpoint(rv32_cpu_state_t *cpu) {
    if (!cpu->cosim_enabled || !cpu->cosim_trace_fp) return;

    cosim_checkpoint_t cp;
    cosim_snapshot(cpu, &cp);

    fprintf(cpu->cosim_trace_fp, "CYCLE %lu PC 0x%08x RETIRED %u UCODE %d",
            (unsigned long)cp.cycle, cp.pc, cp.insns_retired_this_cycle,
            cp.microcode_active);

    for (int i = 0; i < NUM_REGS; i++) {
        fprintf(cpu->cosim_trace_fp, " x%d=0x%08x", i, cp.regs[i]);
    }
    fprintf(cpu->cosim_trace_fp, "\n");
}

/* ========================================================================
 * Performance Reporting (provided — do not modify)
 * ======================================================================== */

void perf_print_summary(const perf_counters_t *perf) {
    printf("\n=== Performance Summary ===\n");
    printf("Total Cycles:          %lu\n", (unsigned long)perf->cycles);
    printf("Instructions Retired:  %lu\n", (unsigned long)perf->insns_retired);

    double cpi = (perf->insns_retired > 0)
        ? (double)perf->cycles / (double)perf->insns_retired
        : 0.0;
    printf("CPI:                   %.3f\n", cpi);

    uint64_t active = perf->dual_issue_cycles + perf->single_issue_cycles;
    double dual_rate = (active > 0)
        ? 100.0 * (double)perf->dual_issue_cycles / (double)active
        : 0.0;
    printf("Dual-Issue Rate:       %.1f%%\n", dual_rate);

    printf("Stall Breakdown:\n");
    printf("  RAW Hazard Stalls:   %lu cycles\n", (unsigned long)perf->raw_hazard_stalls);
    printf("  Load-Use Stalls:     %lu cycles\n", (unsigned long)perf->load_use_stalls);
    printf("  Branch Stalls:       %lu cycles\n", (unsigned long)perf->branch_stalls);
    printf("  Structural Stalls:   %lu cycles\n", (unsigned long)perf->structural_stalls);
    printf("  Microcode Cycles:    %lu cycles\n", (unsigned long)perf->microcode_cycles);
    printf("===========================\n\n");
}

/* ========================================================================
 *
 * ██████████████████████████████████████████████████████████████████████
 * █                                                                    █
 * █   STUDENT IMPLEMENTATION SECTION                                   █
 * █                                                                    █
 * █   Complete all functions below marked with TODO.                   █
 * █   Do NOT change function signatures.                               █
 * █   Use the helpers above: read_with_forward(), write_reg(),         █
 * █   mem_read_word(), etc.                                            █
 * █                                                                    █
 * ██████████████████████████████████████████████████████████████████████
 *
 * ======================================================================== */

/* ========================================================================
 * FETCH STAGE — fetch_dual()
 *
 * Fetch up to 2 instructions from instruction memory.
 *
 * Rules:
 * - Fetch a 64-bit aligned pair: insn at PC and insn at PC+4
 * - If PC is not 8-byte aligned, only fetch the instruction at PC
 *   in Slot 0, Slot 1 is a bubble
 * - If pipeline is stalled (stall_if), do not update IF/ID
 * - If pipeline is flushed (flush_pipeline), insert bubbles
 * - If microcode engine is active, do not fetch (insert bubbles)
 * - Store results in cpu->if_id
 * ======================================================================== */

void fetch_dual(rv32_cpu_state_t *cpu) {
    /* TODO: Implement dual-fetch logic
     *
     * Pseudocode:
     * 1. If stall_if or microcode active, return without updating if_id
     * 2. If flush_pipeline, insert bubbles into if_id and clear flush flag
     * 3. Read instruction word at PC → Slot 0
     * 4. If PC is 8-byte aligned, read instruction at PC+4 → Slot 1
     *    Otherwise Slot 1 is a bubble
     * 5. Advance PC by 4 (single fetch) or 8 (dual fetch)
     */

    (void)cpu; /* Remove this line when you start implementing */

    /* YOUR CODE HERE */
}

/* ========================================================================
 * DECODE STAGE — decode_dual()
 *
 * Decode instructions in IF/ID and produce decoded_insn_t for each slot.
 *
 * Rules:
 * - Decode both slots using decode_instruction()
 * - Check Slot 1 eligibility: only ALU instructions in Slot 1
 * - Check intra-cycle RAW dependency: if Slot 1 reads a register
 *   that Slot 0 writes, squash Slot 1 (make it a bubble)
 * - If Slot 0 is a microcode-trapped instruction, squash Slot 1
 *   and call microcode_dispatch()
 * - If Slot 0 is a branch, Slot 1 can still issue if no data dep
 * - Move decoded results into cpu->id_ex
 * ======================================================================== */

void decode_dual(rv32_cpu_state_t *cpu) {
    /* TODO: Implement dual-decode logic
     *
     * Pseudocode:
     * 1. If stall_id, return without updating id_ex
     * 2. Decode Slot 0: decode_instruction(if_id.insn[0].raw, if_id.insn[0].pc)
     * 3. Decode Slot 1: decode_instruction(if_id.insn[1].raw, if_id.insn[1].pc)
     * 4. Validate Slot 1:
     *    a. If Slot 1 type is not ALU/LUI/AUIPC/NOP → squash to bubble
     *    b. If Slot 0 writes rd and Slot 1 reads rs1 or rs2 == rd → squash
     *    c. If Slot 0 is microcode-trapped → squash Slot 1
     * 5. If Slot 0 needs microcode → call microcode_dispatch(cpu, &slot0)
     * 6. Write decoded results to id_ex
     */

    (void)cpu;

    /* YOUR CODE HERE */
}

/* ========================================================================
 * HAZARD DETECTION — hazard_detect()
 *
 * Detect inter-stage hazards that require pipeline stalls.
 *
 * Returns true if a stall is needed.
 *
 * Check for:
 * 1. Load-use hazard: instruction in ID/EX is a LOAD, and instruction
 *    in IF/ID reads the same register → 1-cycle stall
 *    (forwarding from MEM can't arrive in time for EX)
 * 2. Structural hazard: two memory operations in flight
 *
 * Set cpu->stall_if and cpu->stall_id appropriately.
 * Update perf counters for stall type.
 * ======================================================================== */

bool hazard_detect(rv32_cpu_state_t *cpu) {
    /* TODO: Implement hazard detection
     *
     * Pseudocode:
     * 1. For each valid instruction in id_ex (both slots):
     *    a. If it's a LOAD, check if any instruction in if_id
     *       uses the load's rd as rs1 or rs2
     *    b. If load-use detected: set stall_if = stall_id = true,
     *       insert bubble into id_ex, increment load_use_stalls
     * 2. Return true if stall was inserted
     */

    (void)cpu;

    /* YOUR CODE HERE */

    return false;
}

/* ========================================================================
 * EXECUTE STAGE — execute_dual()
 *
 * Execute up to 2 instructions from ID/EX.
 *
 * For each valid slot:
 * - Read source operands (using forwarding via read_with_forward())
 * - Perform ALU operation / compute branch target / compute address
 * - Write results to ex_result[] and advance to ex_mem pipeline reg
 * - Set up forwarding entries in fwd_ex_mem[]
 * ======================================================================== */

void execute_dual(rv32_cpu_state_t *cpu) {
    /* TODO: Implement dual-execute logic
     *
     * For each slot (0 and 1):
     * 1. If slot not valid, skip
     * 2. Read rs1_val = read_with_forward(cpu, insn.rs1) if uses_rs1
     * 3. Read rs2_val = read_with_forward(cpu, insn.rs2) if uses_rs2
     * 4. Switch on insn.type:
     *    - INSN_TYPE_ALU: compute ALU result based on opcode/funct3/funct7
     *      * R-type (OP): ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND
     *      * I-type (OP_IMM): ADDI, SLTI, SLTIU, XORI, ORI, ANDI, SLLI, SRLI, SRAI
     *    - INSN_TYPE_LUI: result = imm
     *    - INSN_TYPE_AUIPC: result = pc + imm
     *    - INSN_TYPE_LOAD: mem_addr = rs1_val + imm
     *    - INSN_TYPE_STORE: mem_addr = rs1_val + imm, store_data = rs2_val
     *    - INSN_TYPE_BRANCH: compare rs1/rs2, compute branch_target = pc + imm
     *    - INSN_TYPE_JAL: result = pc + 4, branch_target = pc + imm
     *    - INSN_TYPE_JALR: result = pc + 4, branch_target = (rs1_val + imm) & ~1
     *    - INSN_TYPE_SYSTEM: if ECALL/EBREAK, set cpu->halted = true
     *    - INSN_TYPE_FENCE: NOP
     * 5. Set up forwarding: fwd_ex_mem[slot].rd, .value, .valid
     * 6. Handle branches: if taken, set flush_pipeline, update PC to target
     * 7. Write results to cpu->ex_result[slot]
     * 8. Move insn to cpu->ex_mem
     */

    (void)cpu;

    /* YOUR CODE HERE */
}

/* ========================================================================
 * MEMORY STAGE — memory_stage()
 *
 * Perform memory access for load/store instructions.
 *
 * Rules:
 * - Only one memory access per cycle (Slot 0 has priority)
 * - For LOAD: read from memory based on funct3 (LW, LH, LB, LHU, LBU)
 * - For STORE: write to memory based on funct3 (SW, SH, SB)
 * - Update forwarding network: fwd_mem_wb[]
 * - Move results from ex_mem to mem_wb
 * ======================================================================== */

void memory_stage(rv32_cpu_state_t *cpu) {
    /* TODO: Implement memory stage
     *
     * For each slot (0 and 1):
     * 1. If slot not valid, skip
     * 2. If LOAD:
     *    - addr = ex_result[slot].mem_addr
     *    - Switch on funct3:
     *      LW:  result = mem_read_word(cpu, addr)
     *      LH:  result = sign_extend(mem_read_half(cpu, addr), 16)
     *      LHU: result = mem_read_half(cpu, addr)
     *      LB:  result = sign_extend(mem_read_byte(cpu, addr), 8)
     *      LBU: result = mem_read_byte(cpu, addr)
     *    - Update mem_result[slot].alu_result with loaded value
     * 3. If STORE:
     *    - addr = ex_result[slot].mem_addr
     *    - data = ex_result[slot].store_data
     *    - Switch on funct3:
     *      SW: mem_write_word(cpu, addr, data)
     *      SH: mem_write_half(cpu, addr, (uint16_t)data)
     *      SB: mem_write_byte(cpu, addr, (uint8_t)data)
     * 4. For non-memory insns: pass alu_result through
     * 5. Set up fwd_mem_wb[slot] for writeback forwarding
     * 6. Move insn to mem_wb pipeline register
     */

    (void)cpu;

    /* YOUR CODE HERE */
}

/* ========================================================================
 * WRITEBACK STAGE — writeback_dual()
 *
 * Write results back to the register file for up to 2 instructions.
 *
 * Rules:
 * - For each valid slot in mem_wb, write result to rd using write_reg()
 * - Update performance counters:
 *   * insns_retired += number of valid insns in mem_wb
 *   * dual_issue_cycles++ if 2 insns retired
 *   * single_issue_cycles++ if 1 insn retired
 * ======================================================================== */

void writeback_dual(rv32_cpu_state_t *cpu) {
    /* TODO: Implement dual-writeback
     *
     * 1. Count retired instructions this cycle (0, 1, or 2)
     * 2. For each valid slot in mem_wb:
     *    a. If writes_rd and rd != 0:
     *       - For LOAD: write the loaded value
     *       - For ALU/LUI/AUIPC/JAL/JALR: write alu_result
     *    b. Increment insns_retired
     * 3. Update dual_issue_cycles or single_issue_cycles
     * 4. Clear mem_wb after writeback
     */

    (void)cpu;

    /* YOUR CODE HERE */
}

/* ========================================================================
 * MICROCODE DISPATCH — microcode_dispatch()
 *
 * Called when a microcode-trapped instruction is detected in decode.
 * Sets up the microcode engine to begin executing µops.
 *
 * The microcode engine takes over the pipeline:
 * - Pipeline stalls (no new fetches)
 * - µops execute one per cycle through the EX stage
 * - On completion, the result is written back and normal fetch resumes
 * ======================================================================== */

void microcode_dispatch(rv32_cpu_state_t *cpu, decoded_insn_t *insn) {
    /* TODO: Implement microcode dispatch
     *
     * 1. Look up the microcode ROM entry for this instruction
     *    (use microcode_rom_lookup() from microcode_rom.h)
     * 2. Set cpu->microcode.active = true
     * 3. Set cpu->microcode.upc = entry address
     * 4. Set cpu->microcode.uops_remaining = number of µops
     * 5. Copy the trapped instruction to cpu->microcode.trapped_insn
     * 6. Initialize temp registers:
     *    - temp_regs[0] = rs1 value (operand 1)
     *    - temp_regs[1] = rs2 value (operand 2)
     *    - temp_regs[2] = 0 (accumulator)
     *    - temp_regs[3] = 0 (counter/scratch)
     * 7. Set stall_if = true (pipeline stalls during microcode)
     */

    (void)cpu;
    (void)insn;

    /* YOUR CODE HERE */
}

/* ========================================================================
 * MICROCODE STEP — microcode_step()
 *
 * Execute one micro-operation per cycle.
 * Called from cpu_cycle() when microcode engine is active.
 * ======================================================================== */

void microcode_step(rv32_cpu_state_t *cpu) {
    /* TODO: Implement microcode stepping
     *
     * 1. Fetch the current µop from microcode ROM:
     *    micro_op_t uop = microcode_rom_read(cpu->microcode.upc)
     * 2. Read sources based on src1_sel/src2_sel:
     *    - If source is architectural register: read_reg(cpu, src_idx)
     *    - If source is temp register: cpu->microcode.temp_regs[src_idx]
     *    - If source is immediate: uop.immediate
     * 3. Execute ALU operation based on uop.alu_op
     * 4. Write result to destination:
     *    - If dst is temp register: cpu->microcode.temp_regs[dst_idx] = result
     *    - If writes_arch_reg: write_reg(cpu, trapped_insn.rd, result)
     * 5. Advance µPC: cpu->microcode.upc++
     * 6. Decrement uops_remaining
     * 7. If uop.is_last or uops_remaining == 0:
     *    - Set cpu->microcode.active = false
     *    - Set cpu->stall_if = false
     *    - Increment perf.insns_retired (the macro-insn is now retired)
     * 8. Increment perf.microcode_cycles
     */

    (void)cpu;

    /* YOUR CODE HERE */
}

bool microcode_is_active(const rv32_cpu_state_t *cpu) {
    return cpu->microcode.active;
}

/* ========================================================================
 * TOP-LEVEL CYCLE — cpu_cycle() (provided — do not modify)
 *
 * Executes one clock cycle of the pipeline.
 * Stages execute in reverse order (WB first) to model register writes
 * before reads within the same cycle (write-first register file).
 * ======================================================================== */

void cpu_cycle(rv32_cpu_state_t *cpu) {
    if (cpu->halted) return;

    cpu->perf.cycles++;

    /* If microcode engine is active, step it instead of normal pipeline */
    if (microcode_is_active(cpu)) {
        microcode_step(cpu);
        cosim_emit_checkpoint(cpu);
        return;
    }

    /* Normal pipeline execution (reverse order for write-first semantics) */

    /* Stage 5: Writeback */
    writeback_dual(cpu);

    /* Stage 4: Memory */
    memory_stage(cpu);

    /* Stage 3: Execute */
    execute_dual(cpu);

    /* Hazard detection (between decode and execute stages) */
    hazard_detect(cpu);

    /* Stage 2: Decode */
    decode_dual(cpu);

    /* Stage 1: Fetch */
    fetch_dual(cpu);

    /* Emit co-simulation checkpoint */
    cosim_emit_checkpoint(cpu);
}
