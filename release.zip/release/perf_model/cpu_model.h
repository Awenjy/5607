/*
 * cpu_model.h — Dual-Issue RV32I Performance Model Data Structures
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE — co-simulation compatibility depends on it.
 */

#ifndef CPU_MODEL_H
#define CPU_MODEL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

/* ========================================================================
 * Constants
 * ======================================================================== */

#define NUM_REGS        32
#define MEMORY_SIZE     (1 << 20)  /* 1 MB simulated memory */
#define MICROCODE_ROM_SIZE 256     /* Max microcode ROM entries */
#define MAX_UOPS_PER_INSN 40      /* Max µops for one macroinstruction */
#define NUM_ISSUE_SLOTS 2          /* Dual-issue */

/* ========================================================================
 * RV32I Opcode Constants
 * ======================================================================== */

/* Major opcodes */
#define OP_LUI      0x37
#define OP_AUIPC    0x17
#define OP_JAL      0x6F
#define OP_JALR     0x67
#define OP_BRANCH   0x63
#define OP_LOAD     0x03
#define OP_STORE    0x23
#define OP_OP_IMM   0x13
#define OP_OP       0x33
#define OP_MISC_MEM 0x0F
#define OP_SYSTEM   0x73
#define OP_ECALL    0x73

/* funct3 for branches */
#define F3_BEQ  0x0
#define F3_BNE  0x1
#define F3_BLT  0x4
#define F3_BGE  0x5
#define F3_BLTU 0x6
#define F3_BGEU 0x7

/* funct3 for loads */
#define F3_LB   0x0
#define F3_LH   0x1
#define F3_LW   0x2
#define F3_LBU  0x4
#define F3_LHU  0x5

/* funct3 for stores */
#define F3_SB   0x0
#define F3_SH   0x1
#define F3_SW   0x2

/* funct3 for ALU immediate */
#define F3_ADDI  0x0
#define F3_SLTI  0x2
#define F3_SLTIU 0x3
#define F3_XORI  0x4
#define F3_ORI   0x6
#define F3_ANDI  0x7
#define F3_SLLI  0x1
#define F3_SRLI_SRAI 0x5

/* funct3 for ALU register */
#define F3_ADD_SUB  0x0
#define F3_SLL      0x1
#define F3_SLT      0x2
#define F3_SLTU     0x3
#define F3_XOR      0x4
#define F3_SRL_SRA  0x5
#define F3_OR       0x6
#define F3_AND      0x7

/* funct7 */
#define F7_NORMAL   0x00
#define F7_ALT      0x20  /* SUB, SRA */
#define F7_MULDIV   0x01  /* M extension (microcoded) */

/* funct3 for M extension (microcoded) */
#define F3_MUL    0x0
#define F3_MULH   0x1
#define F3_MULHSU 0x2
#define F3_MULHU  0x3
#define F3_DIV    0x4
#define F3_DIVU   0x5
#define F3_REM    0x6
#define F3_REMU   0x7

/* funct3 for SYSTEM (CSR) */
#define F3_CSRRW  0x1
#define F3_CSRRS  0x2
#define F3_CSRRC  0x3
#define F3_CSRRWI 0x5
#define F3_CSRRSI 0x6
#define F3_CSRRCI 0x7

/* ========================================================================
 * Instruction Type Enumeration
 * ======================================================================== */

typedef enum {
    INSN_TYPE_ALU,        /* R-type and I-type ALU */
    INSN_TYPE_LOAD,       /* Load from memory */
    INSN_TYPE_STORE,      /* Store to memory */
    INSN_TYPE_BRANCH,     /* Conditional branch */
    INSN_TYPE_JAL,        /* Jump and link */
    INSN_TYPE_JALR,       /* Jump and link register */
    INSN_TYPE_LUI,        /* Load upper immediate */
    INSN_TYPE_AUIPC,      /* Add upper immediate to PC */
    INSN_TYPE_SYSTEM,     /* CSR / ECALL / EBREAK */
    INSN_TYPE_FENCE,      /* Memory fence (NOP in this model) */
    INSN_TYPE_MICROCODE,  /* Trapped into microcode engine (MUL/DIV/CSR) */
    INSN_TYPE_NOP,        /* NOP / bubble */
    INSN_TYPE_INVALID     /* Unknown instruction */
} insn_type_t;

/* ========================================================================
 * Decoded Instruction
 * ======================================================================== */

typedef struct {
    uint32_t    raw;        /* Raw 32-bit instruction word */
    uint32_t    pc;         /* PC of this instruction */
    insn_type_t type;       /* Classified instruction type */

    /* Decoded fields */
    uint8_t     opcode;     /* [6:0] */
    uint8_t     rd;         /* Destination register [11:7] */
    uint8_t     funct3;     /* [14:12] */
    uint8_t     rs1;        /* Source register 1 [19:15] */
    uint8_t     rs2;        /* Source register 2 [24:20] */
    uint8_t     funct7;     /* [31:25] */
    int32_t     imm;        /* Sign-extended immediate (format-dependent) */

    /* Dependency info */
    bool        uses_rs1;   /* True if rs1 is read */
    bool        uses_rs2;   /* True if rs2 is read */
    bool        writes_rd;  /* True if rd is written */

    /* Microcode */
    bool        needs_microcode;  /* True if this op traps to microcode */
    uint16_t    ucode_entry;      /* Microcode ROM entry point */
    uint8_t     ucode_length;     /* Number of µops */

    /* Valid */
    bool        valid;      /* False for bubbles/squashed instructions */
} decoded_insn_t;

/* ========================================================================
 * Pipeline Stage Registers
 * ======================================================================== */

typedef struct {
    decoded_insn_t insn[NUM_ISSUE_SLOTS];   /* Slot 0 and Slot 1 */
    bool           valid[NUM_ISSUE_SLOTS];  /* Is this slot occupied? */
} pipeline_reg_t;

/* ========================================================================
 * Execution Result (from EX stage)
 * ======================================================================== */

typedef struct {
    uint32_t    alu_result;     /* ALU output */
    uint32_t    mem_addr;       /* Computed memory address (for loads/stores) */
    uint32_t    store_data;     /* Data to store */
    uint32_t    branch_target;  /* Branch/jump target PC */
    bool        branch_taken;   /* Was branch taken? */
    bool        valid;
} exec_result_t;

/* ========================================================================
 * Microcode Engine State
 * ======================================================================== */

/* Single micro-operation */
typedef struct {
    uint8_t     alu_op;         /* ALU operation selector */
    uint8_t     src1_sel;       /* Source 1: register, temp, immediate */
    uint8_t     src2_sel;       /* Source 2: register, temp, immediate */
    uint8_t     dst_sel;        /* Destination: register, temp */
    uint8_t     src1_idx;       /* Register/temp index for source 1 */
    uint8_t     src2_idx;       /* Register/temp index for source 2 */
    uint8_t     dst_idx;        /* Register/temp index for destination */
    int32_t     immediate;      /* Immediate value for this µop */
    bool        writes_arch_reg;/* True if final µop writes to arch reg (rd) */
    bool        is_last;        /* True if this is the final µop in sequence */
} micro_op_t;

/* Microcode ROM entry (one macro-instruction's µop sequence) */
typedef struct {
    uint16_t    entry_addr;     /* Starting address in ROM */
    uint8_t     num_uops;       /* Number of µops in this sequence */
} ucode_entry_t;

/* Microcode engine state */
typedef struct {
    bool        active;         /* Is the microcode engine currently executing? */
    uint16_t    upc;            /* Micro-program counter (index into ROM) */
    uint8_t     uops_remaining; /* µops left in current sequence */
    uint32_t    temp_regs[4];   /* Temporary registers used by µcode sequences */
    decoded_insn_t trapped_insn;/* The macro-instruction that triggered µcode */
} microcode_engine_t;

/* ========================================================================
 * Forwarding Network
 * ======================================================================== */

typedef struct {
    bool        valid;
    uint8_t     rd;             /* Destination register */
    uint32_t    value;          /* Forwarded value */
} forward_entry_t;

/* ========================================================================
 * Performance Counters
 * ======================================================================== */

typedef struct {
    uint64_t    cycles;
    uint64_t    insns_retired;
    uint64_t    dual_issue_cycles;   /* Cycles where 2 insns retired */
    uint64_t    single_issue_cycles; /* Cycles where 1 insn retired */

    /* Stall breakdown */
    uint64_t    raw_hazard_stalls;
    uint64_t    load_use_stalls;
    uint64_t    branch_stalls;
    uint64_t    structural_stalls;
    uint64_t    microcode_cycles;    /* Cycles spent in microcode engine */
} perf_counters_t;

/* ========================================================================
 * Co-Simulation Checkpoint (per-cycle state snapshot)
 * ======================================================================== */

typedef struct {
    uint64_t    cycle;
    uint32_t    pc;
    uint32_t    regs[NUM_REGS];
    uint32_t    insns_retired_this_cycle;  /* 0, 1, or 2 */
    bool        microcode_active;
    uint16_t    upc;
} cosim_checkpoint_t;

/* ========================================================================
 * Top-Level CPU State
 * ======================================================================== */

typedef struct {
    /* Architectural state */
    uint32_t    pc;
    uint32_t    regs[NUM_REGS];         /* x0 is hardwired to 0 */

    /* Memory */
    uint8_t     memory[MEMORY_SIZE];

    /* Pipeline registers */
    pipeline_reg_t  if_id;              /* IF/ID stage register */
    pipeline_reg_t  id_ex;              /* ID/EX stage register */
    pipeline_reg_t  ex_mem;             /* EX/MEM stage register */
    pipeline_reg_t  mem_wb;             /* MEM/WB stage register */

    /* Execution results carried through pipeline */
    exec_result_t   ex_result[NUM_ISSUE_SLOTS];
    exec_result_t   mem_result[NUM_ISSUE_SLOTS];

    /* Forwarding network */
    forward_entry_t fwd_ex_mem[NUM_ISSUE_SLOTS];   /* EX/MEM → EX bypass */
    forward_entry_t fwd_mem_wb[NUM_ISSUE_SLOTS];   /* MEM/WB → EX bypass */

    /* Microcode engine */
    microcode_engine_t microcode;

    /* Performance counters */
    perf_counters_t perf;

    /* Control signals */
    bool        stall_if;       /* Stall fetch stage */
    bool        stall_id;       /* Stall decode stage */
    bool        flush_pipeline; /* Flush on taken branch / misprediction */
    bool        halted;         /* ECALL/EBREAK halt */

    /* Co-simulation */
    bool        cosim_enabled;
    FILE       *cosim_trace_fp; /* File pointer for co-sim trace output */

} rv32_cpu_state_t;

/* ========================================================================
 * Public API
 * ======================================================================== */

/* Lifecycle */
void cpu_init(rv32_cpu_state_t *cpu);
void cpu_reset(rv32_cpu_state_t *cpu, uint32_t entry_pc);
void cpu_load_program(rv32_cpu_state_t *cpu, const uint8_t *program,
                      uint32_t size, uint32_t load_addr);

/* Simulation */
void cpu_cycle(rv32_cpu_state_t *cpu);
bool cpu_is_halted(const rv32_cpu_state_t *cpu);

/* Pipeline stages (students implement these) */
void fetch_dual(rv32_cpu_state_t *cpu);
void decode_dual(rv32_cpu_state_t *cpu);
void execute_dual(rv32_cpu_state_t *cpu);
void memory_stage(rv32_cpu_state_t *cpu);
void writeback_dual(rv32_cpu_state_t *cpu);

/* Hazard detection */
bool hazard_detect(rv32_cpu_state_t *cpu);

/* Microcode */
void microcode_dispatch(rv32_cpu_state_t *cpu, decoded_insn_t *insn);
void microcode_step(rv32_cpu_state_t *cpu);
bool microcode_is_active(const rv32_cpu_state_t *cpu);

/* Co-simulation */
void cosim_snapshot(rv32_cpu_state_t *cpu, cosim_checkpoint_t *cp);
void cosim_emit_checkpoint(rv32_cpu_state_t *cpu);

/* Performance reporting */
void perf_print_summary(const perf_counters_t *perf);

/* Decode helpers */
decoded_insn_t decode_instruction(uint32_t raw_insn, uint32_t pc);

/* Memory access helpers */
uint32_t mem_read_word(const rv32_cpu_state_t *cpu, uint32_t addr);
uint16_t mem_read_half(const rv32_cpu_state_t *cpu, uint32_t addr);
uint8_t  mem_read_byte(const rv32_cpu_state_t *cpu, uint32_t addr);
void     mem_write_word(rv32_cpu_state_t *cpu, uint32_t addr, uint32_t val);
void     mem_write_half(rv32_cpu_state_t *cpu, uint32_t addr, uint16_t val);
void     mem_write_byte(rv32_cpu_state_t *cpu, uint32_t addr, uint8_t val);

#ifdef __cplusplus
}
#endif

#endif /* CPU_MODEL_H */
