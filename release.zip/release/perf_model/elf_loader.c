/*
 * elf_loader.c — Minimal ELF/Binary Loader Implementation
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE.
 *
 * Supports:
 * - Raw binary files (loaded at address 0x00000000)
 * - 32-bit little-endian RISC-V ELF files (PT_LOAD segments)
 */

#include "elf_loader.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ========================================================================
 * Minimal ELF32 structures (to avoid dependency on system elf.h)
 * ======================================================================== */

#define ELF_MAGIC       0x464C457F  /* "\x7FELF" in little-endian */
#define ET_EXEC         2
#define EM_RISCV        243
#define PT_LOAD         1
#define ELFCLASS32      1
#define ELFDATA2LSB     1

#pragma pack(push, 1)

typedef struct {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint32_t e_entry;
    uint32_t e_phoff;
    uint32_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} elf32_ehdr_t;

typedef struct {
    uint32_t p_type;
    uint32_t p_offset;
    uint32_t p_vaddr;
    uint32_t p_paddr;
    uint32_t p_filesz;
    uint32_t p_memsz;
    uint32_t p_flags;
    uint32_t p_align;
} elf32_phdr_t;

#pragma pack(pop)

/* ========================================================================
 * Load Implementation
 * ======================================================================== */

load_result_t load_program(const char *filename, uint8_t *memory, size_t mem_size) {
    load_result_t result = { .entry_point = 0, .load_addr = 0,
                             .size = 0, .success = false };

    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr, "ERROR: Cannot open file '%s'\n", filename);
        return result;
    }

    /* Determine file size */
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (file_size <= 0) {
        fprintf(stderr, "ERROR: File '%s' is empty\n", filename);
        fclose(fp);
        return result;
    }

    /* Read entire file into temp buffer */
    uint8_t *buf = (uint8_t *)malloc(file_size);
    if (!buf) {
        fprintf(stderr, "ERROR: Cannot allocate %ld bytes\n", file_size);
        fclose(fp);
        return result;
    }

    size_t bytes_read = fread(buf, 1, file_size, fp);
    fclose(fp);

    if ((long)bytes_read != file_size) {
        fprintf(stderr, "ERROR: Short read on '%s'\n", filename);
        free(buf);
        return result;
    }

    /* Check for ELF magic */
    uint32_t magic = 0;
    if (file_size >= 4) {
        memcpy(&magic, buf, 4);
    }

    if (magic == ELF_MAGIC) {
        /* ---- Parse as ELF ---- */
        if (file_size < (long)sizeof(elf32_ehdr_t)) {
            fprintf(stderr, "ERROR: File too small for ELF header\n");
            free(buf);
            return result;
        }

        elf32_ehdr_t ehdr;
        memcpy(&ehdr, buf, sizeof(elf32_ehdr_t));

        /* Validate ELF */
        if (ehdr.e_ident[4] != ELFCLASS32) {
            fprintf(stderr, "ERROR: Not a 32-bit ELF\n");
            free(buf);
            return result;
        }
        if (ehdr.e_ident[5] != ELFDATA2LSB) {
            fprintf(stderr, "ERROR: Not little-endian ELF\n");
            free(buf);
            return result;
        }
        if (ehdr.e_machine != EM_RISCV) {
            fprintf(stderr, "ERROR: Not a RISC-V ELF (machine=%u)\n", ehdr.e_machine);
            free(buf);
            return result;
        }

        result.entry_point = ehdr.e_entry;

        /* Load PT_LOAD segments */
        for (int i = 0; i < ehdr.e_phnum; i++) {
            uint32_t phdr_off = ehdr.e_phoff + i * ehdr.e_phentsize;
            if (phdr_off + sizeof(elf32_phdr_t) > (uint32_t)file_size) break;

            elf32_phdr_t phdr;
            memcpy(&phdr, buf + phdr_off, sizeof(elf32_phdr_t));

            if (phdr.p_type != PT_LOAD) continue;

            if (phdr.p_vaddr + phdr.p_memsz > mem_size) {
                fprintf(stderr, "WARNING: Segment at 0x%08x (size %u) exceeds memory\n",
                        phdr.p_vaddr, phdr.p_memsz);
                continue;
            }

            /* Copy file data */
            if (phdr.p_filesz > 0 && phdr.p_offset + phdr.p_filesz <= (uint32_t)file_size) {
                memcpy(memory + phdr.p_vaddr, buf + phdr.p_offset, phdr.p_filesz);
            }

            /* Zero BSS (memsz > filesz) */
            if (phdr.p_memsz > phdr.p_filesz) {
                memset(memory + phdr.p_vaddr + phdr.p_filesz, 0,
                       phdr.p_memsz - phdr.p_filesz);
            }

            if (result.load_addr == 0 || phdr.p_vaddr < result.load_addr) {
                result.load_addr = phdr.p_vaddr;
            }
            result.size += phdr.p_memsz;
        }

        printf("Loaded ELF: entry=0x%08x, %u bytes in %u segments\n",
               result.entry_point, result.size, ehdr.e_phnum);
        result.success = true;

    } else {
        /* ---- Load as raw binary at address 0 ---- */
        if ((size_t)file_size > mem_size) {
            fprintf(stderr, "ERROR: Binary (%ld bytes) exceeds memory (%zu bytes)\n",
                    file_size, mem_size);
            free(buf);
            return result;
        }

        memcpy(memory, buf, file_size);
        result.entry_point = 0x00000000;
        result.load_addr = 0x00000000;
        result.size = (uint32_t)file_size;
        result.success = true;

        printf("Loaded raw binary: %u bytes at 0x00000000\n", result.size);
    }

    free(buf);
    return result;
}
