/*
 * elf_loader.h — Minimal ELF/Binary Loader
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE.
 */

#ifndef ELF_LOADER_H
#define ELF_LOADER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* Load result */
typedef struct {
    uint32_t entry_point;   /* Program entry point PC */
    uint32_t load_addr;     /* Base load address */
    uint32_t size;          /* Total loaded size in bytes */
    bool     success;
} load_result_t;

/*
 * Load a binary or ELF file into memory buffer.
 *
 * If the file starts with the ELF magic (0x7F 'E' 'L' 'F'),
 * it is parsed as a 32-bit RISC-V ELF. Otherwise, it is loaded
 * as a raw binary at address 0x00000000.
 *
 * Parameters:
 *   filename  — path to the binary/ELF file
 *   memory    — pointer to simulated memory buffer
 *   mem_size  — size of the memory buffer
 *
 * Returns load_result_t with entry point and load status.
 */
load_result_t load_program(const char *filename, uint8_t *memory, size_t mem_size);

#ifdef __cplusplus
}
#endif

#endif /* ELF_LOADER_H */
