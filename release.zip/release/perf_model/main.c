/*
 * main.c — Simulation Driver for RV32I Performance Model
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE — autograder depends on this interface.
 *
 * Usage:
 *   ./rv32_sim [options] <program.bin|program.elf>
 *
 * Options:
 *   --stats        Print performance summary after execution
 *   --cosim        Enable co-simulation trace output (stdout)
 *   --cosim-file F Write co-simulation trace to file F
 *   --max-cycles N Stop after N cycles (default: 1000000)
 *   --verbose      Print instruction-by-instruction trace
 *   --help         Print usage
 */

#include "cpu_model.h"
#include "elf_loader.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

/* ========================================================================
 * Configuration
 * ======================================================================== */

typedef struct {
    const char *program_file;
    const char *cosim_file;
    bool        print_stats;
    bool        cosim_enabled;
    bool        verbose;
    uint64_t    max_cycles;
} sim_config_t;

static void print_usage(const char *prog) {
    printf("Usage: %s [options] <program.bin|program.elf>\n\n", prog);
    printf("Options:\n");
    printf("  --stats           Print performance summary after execution\n");
    printf("  --cosim           Enable co-simulation trace output (stdout)\n");
    printf("  --cosim-file F    Write co-simulation trace to file F\n");
    printf("  --max-cycles N    Stop after N cycles (default: 1000000)\n");
    printf("  --verbose         Print instruction-by-instruction trace\n");
    printf("  --help            Print this usage message\n");
}

static sim_config_t parse_args(int argc, char **argv) {
    sim_config_t cfg = {
        .program_file = NULL,
        .cosim_file = NULL,
        .print_stats = false,
        .cosim_enabled = false,
        .verbose = false,
        .max_cycles = 1000000
    };

    static struct option long_opts[] = {
        {"stats",      no_argument,       NULL, 's'},
        {"cosim",      no_argument,       NULL, 'c'},
        {"cosim-file", required_argument, NULL, 'f'},
        {"max-cycles", required_argument, NULL, 'm'},
        {"verbose",    no_argument,       NULL, 'v'},
        {"help",       no_argument,       NULL, 'h'},
        {NULL, 0, NULL, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "scf:m:vh", long_opts, NULL)) != -1) {
        switch (opt) {
        case 's': cfg.print_stats = true; break;
        case 'c': cfg.cosim_enabled = true; break;
        case 'f': cfg.cosim_file = optarg; cfg.cosim_enabled = true; break;
        case 'm': cfg.max_cycles = strtoull(optarg, NULL, 10); break;
        case 'v': cfg.verbose = true; break;
        case 'h': print_usage(argv[0]); exit(0);
        default:  print_usage(argv[0]); exit(1);
        }
    }

    if (optind < argc) {
        cfg.program_file = argv[optind];
    } else {
        fprintf(stderr, "ERROR: No program file specified.\n\n");
        print_usage(argv[0]);
        exit(1);
    }

    return cfg;
}

/* ========================================================================
 * Main
 * ======================================================================== */

int main(int argc, char **argv) {
    sim_config_t cfg = parse_args(argc, argv);

    printf("=== RV32I Dual-Issue Performance Model ===\n");
    printf("Program: %s\n", cfg.program_file);
    printf("Max cycles: %lu\n", (unsigned long)cfg.max_cycles);

    /* Initialize CPU */
    rv32_cpu_state_t cpu;
    cpu_init(&cpu);

    /* Load program */
    load_result_t lr = load_program(cfg.program_file, cpu.memory, MEMORY_SIZE);
    if (!lr.success) {
        fprintf(stderr, "ERROR: Failed to load program '%s'\n", cfg.program_file);
        return 1;
    }

    /* Reset CPU to entry point */
    cpu_reset(&cpu, lr.entry_point);

    /* Set up co-simulation */
    if (cfg.cosim_enabled) {
        cpu.cosim_enabled = true;
        if (cfg.cosim_file) {
            cpu.cosim_trace_fp = fopen(cfg.cosim_file, "w");
            if (!cpu.cosim_trace_fp) {
                fprintf(stderr, "ERROR: Cannot open co-sim file '%s'\n",
                        cfg.cosim_file);
                return 1;
            }
        } else {
            cpu.cosim_trace_fp = stdout;
        }
    }

    /* Run simulation */
    printf("Simulation started (entry=0x%08x)...\n", lr.entry_point);

    while (!cpu_is_halted(&cpu) && cpu.perf.cycles < cfg.max_cycles) {
        cpu_cycle(&cpu);

        if (cfg.verbose && !microcode_is_active(&cpu)) {
            printf("[Cycle %6lu] PC=0x%08x",
                   (unsigned long)cpu.perf.cycles, cpu.pc);
            for (int s = 0; s < NUM_ISSUE_SLOTS; s++) {
                if (cpu.mem_wb.valid[s]) {
                    printf("  Slot%d: insn=0x%08x", s,
                           cpu.mem_wb.insn[s].raw);
                }
            }
            printf("\n");
        }
    }

    /* Report reason for stopping */
    if (cpu_is_halted(&cpu)) {
        printf("Simulation halted (ECALL/EBREAK) at cycle %lu\n",
               (unsigned long)cpu.perf.cycles);
    } else {
        printf("Simulation stopped at max cycle limit (%lu)\n",
               (unsigned long)cfg.max_cycles);
    }

    /* Print performance stats */
    if (cfg.print_stats) {
        perf_print_summary(&cpu.perf);
    }

    /* Print final register state */
    printf("\n=== Final Register State ===\n");
    for (int i = 0; i < 32; i += 4) {
        printf("  x%-2d=0x%08x  x%-2d=0x%08x  x%-2d=0x%08x  x%-2d=0x%08x\n",
               i, cpu.regs[i], i+1, cpu.regs[i+1],
               i+2, cpu.regs[i+2], i+3, cpu.regs[i+3]);
    }

    /* Report test pass/fail based on x10 (a0) register */
    printf("\n=== Test Result ===\n");
    if (cpu.regs[10] == 0) {
        printf("PASS (a0 = 0)\n");
    } else {
        printf("FAIL (a0 = %d)\n", (int32_t)cpu.regs[10]);
    }

    /* Cleanup */
    if (cpu.cosim_trace_fp && cpu.cosim_trace_fp != stdout) {
        fclose(cpu.cosim_trace_fp);
    }

    return (cpu.regs[10] == 0) ? 0 : 1;
}
