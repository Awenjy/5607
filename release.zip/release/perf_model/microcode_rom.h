/*
 * microcode_rom.h — Microcode ROM Interface
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE.
 */

#ifndef MICROCODE_ROM_H
#define MICROCODE_ROM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cpu_model.h"

/* ========================================================================
 * Microcode ALU Operations
 * ======================================================================== */

#define UALU_ADD    0x00
#define UALU_SUB    0x01
#define UALU_AND    0x02
#define UALU_OR     0x03
#define UALU_XOR    0x04
#define UALU_SLL    0x05
#define UALU_SRL    0x06
#define UALU_SRA    0x07
#define UALU_SLT    0x08
#define UALU_SLTU   0x09
#define UALU_PASS1  0x0A  /* Pass source 1 through */
#define UALU_PASS2  0x0B  /* Pass source 2 through */
#define UALU_NOP    0x0F

/* ========================================================================
 * Microcode Source / Destination Selectors
 * ======================================================================== */

#define USRC_ARCH_REG  0   /* Architectural register (rs1/rs2) */
#define USRC_TEMP_REG  1   /* Microcode temporary register (temp_regs[]) */
#define USRC_IMMEDIATE 2   /* Immediate value from µop */

#define UDST_ARCH_REG  0   /* Write to architectural rd */
#define UDST_TEMP_REG  1   /* Write to temp register */
#define UDST_NONE      2   /* No write (compare, branch, etc.) */

/* ========================================================================
 * Microcode ROM Entry Points
 *
 * Each entry point corresponds to a specific macroinstruction that traps
 * into the microcode engine.
 * ======================================================================== */

#define UCODE_ENTRY_MUL     0x00   /* MUL rd, rs1, rs2 (8 uops) */
#define UCODE_ENTRY_MULH    0x10   /* MULH rd, rs1, rs2 (10 uops) */
#define UCODE_ENTRY_DIV     0x20   /* DIV rd, rs1, rs2 (34 uops) */
#define UCODE_ENTRY_DIVU    0x50   /* DIVU rd, rs1, rs2 (34 uops) */
#define UCODE_ENTRY_REM     0x80   /* REM rd, rs1, rs2 (34 uops) */
#define UCODE_ENTRY_REMU    0xB0   /* REMU rd, rs1, rs2 (34 uops) */
#define UCODE_ENTRY_CSRRW   0xE0   /* CSRRW (3 uops) */
#define UCODE_ENTRY_CSRRS   0xE4   /* CSRRS (3 uops) */
#define UCODE_ENTRY_CSRRC   0xE8   /* CSRRC (3 uops) */

/* Number of µops per operation */
#define UCODE_LEN_MUL    8
#define UCODE_LEN_MULH   10
#define UCODE_LEN_DIV    34
#define UCODE_LEN_DIVU   34
#define UCODE_LEN_REM    34
#define UCODE_LEN_REMU   34
#define UCODE_LEN_CSR    3

/* ========================================================================
 * Microcode ROM API
 * ======================================================================== */

/* Initialize the microcode ROM (called once at startup) */
void microcode_rom_init(void);

/* Look up the ROM entry for a decoded instruction.
 * Returns the entry address and sets *num_uops.
 * Returns 0xFFFF if the instruction is not microcoded. */
uint16_t microcode_rom_lookup(const decoded_insn_t *insn, uint8_t *num_uops);

/* Read a single µop from the ROM at the given address */
micro_op_t microcode_rom_read(uint16_t addr);

#ifdef __cplusplus
}
#endif

#endif /* MICROCODE_ROM_H */
