# RTL Generation Guide

## What to Do

Use an **LLM (Large Language Model)** to generate SystemVerilog modules that implement the dual-issue RV32I pipeline described in the lab handout and modeled by your C performance model.

## Constraints

1. **Top-level module**: Must be named `rv32_top` with the exact port interface defined in [`rv32_top.sv`](rv32_top.sv). **Do not change the port names or widths.**

2. **Package**: Use the type definitions in [`rv32_pkg.sv`](rv32_pkg.sv). You may add new types but do not remove existing ones.

3. **Sub-modules**: You may organize your RTL into any sub-module hierarchy. Suggested:
   - `rv32_fetch.sv` — Dual instruction fetch
   - `rv32_decode.sv` — Dual decode with issue logic
   - `rv32_execute.sv` — Dual ALU execution
   - `rv32_memory.sv` — Load/store memory access
   - `rv32_writeback.sv` — Dual register writeback
   - `rv32_hazard.sv` — Hazard detection and forwarding
   - `rv32_microcode.sv` — Microcode engine (ROM + µPC sequencer)
   - `rv32_regfile.sv` — 2-read, 2-write register file
   - `rv32_imem.sv` — Instruction memory
   - `rv32_dmem.sv` — Data memory

4. **Debug outputs**: The co-simulation testbench reads `o_debug_regs[0:31]` every cycle. Make sure your register file values are continuously driven to these ports.

## Suggested LLM Prompting Strategy

1. **Start with the spec**: Give the LLM your C model code (`cpu_model.c`) and the `rv32_top.sv` interface. Ask it to generate each sub-module one at a time.

2. **Iterate on errors**: Verilator will catch syntax errors, undeclared signals, etc. Feed error messages back to the LLM and ask for fixes.

3. **Use co-simulation**: Run `make cosim TEST=test_alu_basic` to find functional mismatches. Share the mismatch output with the LLM to debug.

4. **Document everything**: Record your prompts and the LLM's responses in `submission/part_c/llm_prompts.md`.

## Example First Prompt

```
I'm building a dual-issue in-order 5-stage RV32I pipelined processor in SystemVerilog.
Here is the top-level port interface: [paste rv32_top.sv]
Here is the package with type definitions: [paste rv32_pkg.sv]
Here is my C reference model: [paste cpu_model.c]

Please generate the rv32_fetch module that:
- Fetches up to 2 instructions per cycle from instruction memory
- Outputs decoded instruction pairs to the IF/ID pipeline register
- Supports stalling (stall_if input) and flushing (flush input)
- On taken branch, the next fetch address comes from branch_target input
```

Good luck! Start early and iterate often.
