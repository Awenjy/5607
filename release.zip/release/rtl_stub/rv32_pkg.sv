/*
 * rv32_pkg.sv — Shared Type Definitions for RV32I Dual-Issue Pipeline
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 *
 * This package defines shared types, enums, and constants used across
 * all RTL modules. Students may extend this package but must not
 * change existing definitions (co-simulation depends on them).
 */

package rv32_pkg;

    // ============================================================
    // Pipeline Constants
    // ============================================================
    localparam int NUM_REGS       = 32;
    localparam int NUM_ISSUE_SLOTS = 2;
    localparam int XLEN           = 32;
    localparam int MEM_SIZE       = 1 << 20;  // 1 MB
    localparam int UCODE_ROM_SIZE = 256;

    // ============================================================
    // Opcodes (RV32I + M extension trap)
    // ============================================================
    typedef enum logic [6:0] {
        OPC_LUI      = 7'h37,
        OPC_AUIPC    = 7'h17,
        OPC_JAL      = 7'h6F,
        OPC_JALR     = 7'h67,
        OPC_BRANCH   = 7'h63,
        OPC_LOAD     = 7'h03,
        OPC_STORE    = 7'h23,
        OPC_OP_IMM   = 7'h13,
        OPC_OP       = 7'h33,
        OPC_MISC_MEM = 7'h0F,
        OPC_SYSTEM   = 7'h73
    } opcode_t;

    // ============================================================
    // Instruction Type Classification
    // ============================================================
    typedef enum logic [3:0] {
        ITYPE_ALU       = 4'd0,
        ITYPE_LOAD      = 4'd1,
        ITYPE_STORE     = 4'd2,
        ITYPE_BRANCH    = 4'd3,
        ITYPE_JAL       = 4'd4,
        ITYPE_JALR      = 4'd5,
        ITYPE_LUI       = 4'd6,
        ITYPE_AUIPC     = 4'd7,
        ITYPE_SYSTEM    = 4'd8,
        ITYPE_FENCE     = 4'd9,
        ITYPE_MICROCODE = 4'd10,
        ITYPE_NOP       = 4'd11,
        ITYPE_INVALID   = 4'd15
    } insn_type_t;

    // ============================================================
    // ALU Operation Selector
    // ============================================================
    typedef enum logic [3:0] {
        ALU_ADD  = 4'd0,
        ALU_SUB  = 4'd1,
        ALU_AND  = 4'd2,
        ALU_OR   = 4'd3,
        ALU_XOR  = 4'd4,
        ALU_SLL  = 4'd5,
        ALU_SRL  = 4'd6,
        ALU_SRA  = 4'd7,
        ALU_SLT  = 4'd8,
        ALU_SLTU = 4'd9,
        ALU_PASS = 4'd10
    } alu_op_t;

    // ============================================================
    // Decoded Instruction (flows through pipeline)
    // ============================================================
    typedef struct packed {
        logic [31:0] pc;
        logic [31:0] raw_insn;
        insn_type_t  itype;
        logic [4:0]  rd;
        logic [4:0]  rs1;
        logic [4:0]  rs2;
        logic [2:0]  funct3;
        logic [6:0]  funct7;
        logic [31:0] imm;
        alu_op_t     alu_op;
        logic        uses_rs1;
        logic        uses_rs2;
        logic        writes_rd;
        logic        needs_microcode;
        logic        valid;
    } decoded_insn_t;

    // ============================================================
    // Pipeline Stage Register (dual-slot)
    // ============================================================
    typedef struct packed {
        decoded_insn_t insn;
        logic          valid;
        logic [31:0]   rs1_val;
        logic [31:0]   rs2_val;
        logic [31:0]   alu_result;
        logic [31:0]   mem_addr;
        logic [31:0]   store_data;
        logic [31:0]   branch_target;
        logic          branch_taken;
    } pipe_entry_t;

    // ============================================================
    // Microcode µop
    // ============================================================
    typedef struct packed {
        logic [3:0]  alu_op;
        logic [1:0]  src1_sel;
        logic [1:0]  src2_sel;
        logic [1:0]  dst_sel;
        logic [2:0]  src1_idx;
        logic [2:0]  src2_idx;
        logic [2:0]  dst_idx;
        logic [31:0] immediate;
        logic        writes_arch_reg;
        logic        is_last;
    } micro_op_t;

endpackage
