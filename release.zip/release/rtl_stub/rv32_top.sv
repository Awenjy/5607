/*
 * rv32_top.sv — Top-Level Module Interface for Dual-Issue RV32I Pipeline
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 *
 * STUDENTS: Use an LLM to generate the implementation of this module
 * and all sub-modules. The port interface below MUST NOT be changed —
 * the co-simulation testbench depends on these exact port names.
 *
 * Your implementation should instantiate sub-modules for:
 *   - Fetch unit (dual-fetch from instruction memory)
 *   - Decode unit (dual-decode with issue logic)
 *   - Execute unit (dual ALU)
 *   - Memory unit (load/store)
 *   - Writeback unit (dual writeback to register file)
 *   - Hazard detection and forwarding network
 *   - Microcode engine (ROM + sequencer)
 *   - Register file (2-read, 2-write ports)
 *   - Instruction memory (initialized from test program)
 *   - Data memory
 */

import rv32_pkg::*;

module rv32_top (
    // Clock and Reset
    input  logic        i_clk,
    input  logic        i_rst_n,        // Active-low synchronous reset

    // ============================================================
    // Debug / Co-Simulation Outputs
    // These ports are read by the co-simulation testbench every cycle.
    // They must reflect the committed architectural state.
    // ============================================================

    // Program Counter
    output logic [31:0] o_pc,

    // Architectural Register File (debug read ports)
    // o_debug_regs[0] = x0 (always 0), ..., o_debug_regs[31] = x31
    output logic [31:0] o_debug_regs [0:31],

    // Halt signal (asserted on ECALL/EBREAK)
    output logic        o_halted,

    // Microcode engine status
    output logic        o_microcode_active,
    output logic [15:0] o_upc,

    // Instructions retired this cycle (0, 1, or 2)
    output logic [1:0]  o_insns_retired,

    // ============================================================
    // Memory Interface (optional — for external memory models)
    // For this lab, instruction and data memory can be internal.
    // These ports are provided for future extensibility.
    // ============================================================

    // Instruction memory read port
    output logic [31:0] o_imem_addr,
    input  logic [63:0] i_imem_rdata,   // 64-bit read for dual-fetch
    output logic        o_imem_re,

    // Data memory read/write port
    output logic [31:0] o_dmem_addr,
    output logic [31:0] o_dmem_wdata,
    input  logic [31:0] i_dmem_rdata,
    output logic [3:0]  o_dmem_we,      // Byte-enable write mask
    output logic        o_dmem_re
);

    // ============================================================
    //
    // TODO: Students generate the implementation using an LLM.
    //
    // Suggested sub-module hierarchy:
    //
    //   rv32_top
    //   ├── rv32_fetch       — Dual instruction fetch
    //   ├── rv32_decode      — Dual decode + issue logic
    //   ├── rv32_execute     — Dual ALU execution
    //   ├── rv32_memory      — Load/store memory access
    //   ├── rv32_writeback   — Dual register writeback
    //   ├── rv32_hazard      — Hazard detection + forwarding
    //   ├── rv32_microcode   — Microcode engine (ROM + µPC)
    //   ├── rv32_regfile     — 2R2W register file
    //   ├── rv32_imem        — Instruction memory (internal SRAM)
    //   └── rv32_dmem        — Data memory (internal SRAM)
    //
    // ============================================================

    // Placeholder assignments (remove when implementing)
    assign o_pc              = 32'h0;
    assign o_halted          = 1'b0;
    assign o_microcode_active = 1'b0;
    assign o_upc             = 16'h0;
    assign o_insns_retired   = 2'b0;
    assign o_imem_addr       = 32'h0;
    assign o_imem_re         = 1'b0;
    assign o_dmem_addr       = 32'h0;
    assign o_dmem_wdata      = 32'h0;
    assign o_dmem_we         = 4'h0;
    assign o_dmem_re         = 1'b0;

    // Debug register outputs (placeholder)
    genvar gi;
    generate
        for (gi = 0; gi < 32; gi++) begin : gen_debug_regs
            assign o_debug_regs[gi] = 32'h0;
        end
    endgenerate

endmodule
