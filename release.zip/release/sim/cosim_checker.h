/*
 * cosim_checker.h — Co-Simulation State Comparison Utilities
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE.
 */

#ifndef COSIM_CHECKER_H
#define COSIM_CHECKER_H

#include <cstdint>
#include <cstdio>
#include <cstring>

#define COSIM_NUM_REGS 32

struct CosimState {
    uint64_t cycle;
    uint32_t pc;
    uint32_t regs[COSIM_NUM_REGS];
    uint32_t insns_retired;
    bool     microcode_active;
    uint16_t upc;
};

/*
 * Compare two co-simulation states.
 * Returns true if they match, false if mismatch.
 * On mismatch, prints detailed diff to stderr.
 */
static inline bool cosim_compare(const CosimState &model, const CosimState &rtl,
                                 uint64_t cycle) {
    bool match = true;

    if (model.pc != rtl.pc) {
        fprintf(stderr, "COSIM MISMATCH at cycle %lu:\n", (unsigned long)cycle);
        fprintf(stderr, "  PC: C_Model=0x%08x  RTL=0x%08x\n",
                model.pc, rtl.pc);
        match = false;
    }

    for (int i = 0; i < COSIM_NUM_REGS; i++) {
        if (model.regs[i] != rtl.regs[i]) {
            if (match) {
                fprintf(stderr, "COSIM MISMATCH at cycle %lu:\n",
                        (unsigned long)cycle);
            }
            fprintf(stderr, "  x%-2d: C_Model=0x%08x  RTL=0x%08x  <-- MISMATCH\n",
                    i, model.regs[i], rtl.regs[i]);
            match = false;
        }
    }

    if (model.microcode_active != rtl.microcode_active) {
        if (match) {
            fprintf(stderr, "COSIM MISMATCH at cycle %lu:\n",
                    (unsigned long)cycle);
        }
        fprintf(stderr, "  Microcode Active: C_Model=%d  RTL=%d\n",
                model.microcode_active, rtl.microcode_active);
        match = false;
    }

    return match;
}

/*
 * Print a co-simulation state for debugging.
 */
static inline void cosim_print_state(const char *label, const CosimState &s) {
    printf("[%s] Cycle=%lu PC=0x%08x Retired=%u µCode=%d\n",
           label, (unsigned long)s.cycle, s.pc, s.insns_retired,
           s.microcode_active);
    for (int i = 0; i < COSIM_NUM_REGS; i += 4) {
        printf("  x%-2d=0x%08x  x%-2d=0x%08x  x%-2d=0x%08x  x%-2d=0x%08x\n",
               i, s.regs[i], i+1, s.regs[i+1],
               i+2, s.regs[i+2], i+3, s.regs[i+3]);
    }
}

#endif /* COSIM_CHECKER_H */
