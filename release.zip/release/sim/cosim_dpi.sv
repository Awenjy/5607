/*
 * cosim_dpi.sv — DPI-C Interface for Co-Simulation
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 *
 * This module provides a SystemVerilog DPI-C bridge for loading
 * test programs into RTL memory. Students do not need to modify this.
 */

// DPI-C import functions for memory initialization
import "DPI-C" function int load_binary_to_mem(
    input string filename,
    output int entry_point
);

module cosim_mem_init #(
    parameter MEM_SIZE = 1048576  // 1 MB
) (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        load_en,    // Pulse high to trigger load
    input  string       filename,   // Path to binary/ELF file
    output logic [31:0] entry_pc,   // Loaded entry point
    output logic        load_done,  // High when load complete
    output logic        load_error  // High on load failure
);

    logic load_triggered;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            entry_pc     <= 32'h0;
            load_done    <= 1'b0;
            load_error   <= 1'b0;
            load_triggered <= 1'b0;
        end else if (load_en && !load_triggered) begin
            int ep;
            int result;
            result = load_binary_to_mem(filename, ep);
            if (result == 0) begin
                entry_pc   <= ep[31:0];
                load_done  <= 1'b1;
                load_error <= 1'b0;
            end else begin
                load_done  <= 1'b1;
                load_error <= 1'b1;
            end
            load_triggered <= 1'b1;
        end
    end

endmodule
