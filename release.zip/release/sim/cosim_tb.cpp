/*
 * cosim_tb.cpp — Verilator Co-Simulation Testbench
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 * DO NOT MODIFY THIS FILE.
 *
 * This testbench:
 * 1. Instantiates the RTL DUT (rv32_top) via Verilator
 * 2. Instantiates the C performance model
 * 3. Loads a test program into both
 * 4. Each clock cycle: advances both, compares architectural state
 * 5. On mismatch: dumps details and exits with error
 * 6. On completion: reports pass/fail and cycle count comparison
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>

/* Verilator generated header */
#include "Vrv32_top.h"
#include "verilated.h"

/* Co-simulation checker */
#include "cosim_checker.h"

/* C performance model (extern "C" linkage) */
extern "C" {
#include "../perf_model/cpu_model.h"
#include "../perf_model/elf_loader.h"
}

/* Global memory pointer for DPI-C access from RTL */
static const uint8_t *g_cosim_memory = nullptr;

extern "C" uint8_t sim_read_mem_byte(int addr) {
    if (g_cosim_memory && addr >= 0 && addr < MEMORY_SIZE) {
        return g_cosim_memory[addr];
    }
    return 0;
}

/* ========================================================================
 * Configuration
 * ======================================================================== */

#define MAX_CYCLES  1000000
#define TIMEOUT_MSG "ERROR: Simulation timed out after %d cycles\n"

/* ========================================================================
 * Extract RTL State
 *
 * Read the architectural state from the Verilator DUT via its
 * top-level output ports. The student's rv32_top module must expose:
 *   - o_pc [31:0]
 *   - o_regs [31:0][31:0] (flattened to 32 × 32-bit outputs)
 *   - o_halted
 *   - o_microcode_active
 *   - o_upc [15:0]
 *   - o_insns_retired [1:0] (0, 1, or 2)
 * ======================================================================== */

static CosimState extract_rtl_state(Vrv32_top *dut, uint64_t cycle) {
    CosimState s;
    memset(&s, 0, sizeof(s));
    s.cycle = cycle;
    s.pc = dut->o_pc;

    /* Read register file outputs
     * The RTL must expose o_regs_0, o_regs_1, ..., o_regs_31
     * as individual 32-bit output ports. */
    /* NOTE: For simplicity, we read from a flat array if the
     * Verilator model exposes it via DPI or public members.
     * Students should ensure their rv32_top module includes:
     *   output logic [31:0] o_debug_regs [0:31]
     * which Verilator maps to dut->o_debug_regs[i] */
    for (int i = 0; i < 32; i++) {
        s.regs[i] = dut->o_debug_regs[i];
    }

    s.microcode_active = dut->o_microcode_active;
    s.insns_retired = dut->o_insns_retired;
    return s;
}

/* ========================================================================
 * Extract C Model State
 * ======================================================================== */

static CosimState extract_model_state(rv32_cpu_state_t *cpu, uint64_t cycle) {
    CosimState s;
    memset(&s, 0, sizeof(s));
    s.cycle = cycle;
    s.pc = cpu->pc;
    memcpy(s.regs, cpu->regs, sizeof(s.regs));
    s.microcode_active = cpu->microcode.active;
    s.upc = cpu->microcode.upc;

    /* Count retired instructions this cycle */
    s.insns_retired = 0;
    for (int slot = 0; slot < NUM_ISSUE_SLOTS; slot++) {
        if (cpu->mem_wb.valid[slot] && cpu->mem_wb.insn[slot].valid) {
            s.insns_retired++;
        }
    }

    return s;
}

/* ========================================================================
 * Main
 * ======================================================================== */

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <program.bin|program.elf>\n", argv[0]);
        return 1;
    }

    const char *program_file = argv[1];
    printf("=== RV32I Co-Simulation Testbench ===\n");
    printf("Program: %s\n", program_file);

    /* ---- Initialize Verilator ---- */
    Verilated::commandArgs(argc, argv);
    Vrv32_top *dut = new Vrv32_top;

    /* ---- Initialize C Model ---- */
    rv32_cpu_state_t cpu;
    cpu_init(&cpu);

    /* ---- Load Program ---- */
    load_result_t lr = load_program(program_file, cpu.memory, MEMORY_SIZE);
    if (!lr.success) {
        fprintf(stderr, "ERROR: Failed to load program\n");
        delete dut;
        return 1;
    }

    cpu_reset(&cpu, lr.entry_point);
    g_cosim_memory = cpu.memory;

    /* Load same program into RTL memory via initialization signals */
    dut->i_clk = 0;
    dut->i_rst_n = 0;
    dut->eval();

    /* Assert reset for 5 cycles */
    for (int i = 0; i < 10; i++) {
        dut->i_clk = !dut->i_clk;
        dut->eval();
    }
    dut->i_rst_n = 1;

    /* ---- Co-Simulation Loop ---- */
    uint64_t cycle = 0;
    uint64_t mismatches = 0;
    bool model_halted = false;
    bool rtl_halted = false;

    printf("Starting lock-step co-simulation...\n\n");

    while (cycle < MAX_CYCLES) {
        /* Advance RTL: rising edge */
        dut->i_clk = 1;
        dut->eval();

        /* Advance C model */
        cpu_cycle(&cpu);

        /* Falling edge */
        dut->i_clk = 0;
        dut->eval();

        cycle++;

        /* Extract states */
        CosimState rtl_state = extract_rtl_state(dut, cycle);
        CosimState model_state = extract_model_state(&cpu, cycle);

        /* Compare */
        if (!cosim_compare(model_state, rtl_state, cycle)) {
            mismatches++;
            fprintf(stderr, "  C Model state:\n");
            cosim_print_state("C_MODEL", model_state);
            fprintf(stderr, "  RTL state:\n");
            cosim_print_state("RTL", rtl_state);
            fprintf(stderr, "\n");

            if (mismatches >= 10) {
                fprintf(stderr, "ERROR: Too many mismatches (%lu), aborting.\n",
                        (unsigned long)mismatches);
                break;
            }
        }

        /* Check halt conditions */
        model_halted = cpu_is_halted(&cpu);
        rtl_halted = dut->o_halted;

        if (model_halted && rtl_halted) {
            printf("Both C model and RTL halted at cycle %lu\n",
                   (unsigned long)cycle);
            break;
        }

        if (model_halted != rtl_halted) {
            fprintf(stderr, "COSIM MISMATCH: Halt state differs at cycle %lu\n",
                    (unsigned long)cycle);
            fprintf(stderr, "  C_Model halted=%d, RTL halted=%d\n",
                    model_halted, rtl_halted);
            mismatches++;
        }
    }

    if (cycle >= MAX_CYCLES) {
        fprintf(stderr, TIMEOUT_MSG, MAX_CYCLES);
    }

    /* ---- Report Results ---- */
    printf("\n=== Co-Simulation Results ===\n");
    printf("Total cycles:    %lu\n", (unsigned long)cycle);
    printf("Mismatches:      %lu\n", (unsigned long)mismatches);
    printf("C Model CPI:     %.3f\n",
           cpu.perf.insns_retired > 0
               ? (double)cpu.perf.cycles / (double)cpu.perf.insns_retired
               : 0.0);
    printf("C Model insns:   %lu\n", (unsigned long)cpu.perf.insns_retired);

    if (mismatches == 0) {
        printf("\n*** COSIM PASS ***\n\n");
    } else {
        printf("\n*** COSIM FAIL (%lu mismatches) ***\n\n",
               (unsigned long)mismatches);
    }

    /* Check test result (a0 register) */
    int test_result = (cpu.regs[10] == 0 && mismatches == 0) ? 0 : 1;

    /* Cleanup */
    delete dut;

    return test_result;
}
