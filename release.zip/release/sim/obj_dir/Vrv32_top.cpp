// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vrv32_top__pch.h"

//============================================================
// Constructors

Vrv32_top::Vrv32_top(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vrv32_top__Syms(contextp(), _vcname__, this)}
    , i_clk{vlSymsp->TOP.i_clk}
    , i_rst_n{vlSymsp->TOP.i_rst_n}
    , o_halted{vlSymsp->TOP.o_halted}
    , o_microcode_active{vlSymsp->TOP.o_microcode_active}
    , o_insns_retired{vlSymsp->TOP.o_insns_retired}
    , o_imem_re{vlSymsp->TOP.o_imem_re}
    , o_dmem_we{vlSymsp->TOP.o_dmem_we}
    , o_dmem_re{vlSymsp->TOP.o_dmem_re}
    , o_upc{vlSymsp->TOP.o_upc}
    , o_pc{vlSymsp->TOP.o_pc}
    , o_imem_addr{vlSymsp->TOP.o_imem_addr}
    , o_dmem_addr{vlSymsp->TOP.o_dmem_addr}
    , o_dmem_wdata{vlSymsp->TOP.o_dmem_wdata}
    , i_dmem_rdata{vlSymsp->TOP.i_dmem_rdata}
    , i_imem_rdata{vlSymsp->TOP.i_imem_rdata}
    , o_debug_regs{vlSymsp->TOP.o_debug_regs}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vrv32_top::Vrv32_top(const char* _vcname__)
    : Vrv32_top(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vrv32_top::~Vrv32_top() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vrv32_top___024root___eval_debug_assertions(Vrv32_top___024root* vlSelf);
#endif  // VL_DEBUG
void Vrv32_top___024root___eval_static(Vrv32_top___024root* vlSelf);
void Vrv32_top___024root___eval_initial(Vrv32_top___024root* vlSelf);
void Vrv32_top___024root___eval_settle(Vrv32_top___024root* vlSelf);
void Vrv32_top___024root___eval(Vrv32_top___024root* vlSelf);

void Vrv32_top::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vrv32_top::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vrv32_top___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vrv32_top___024root___eval_static(&(vlSymsp->TOP));
        Vrv32_top___024root___eval_initial(&(vlSymsp->TOP));
        Vrv32_top___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vrv32_top___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vrv32_top::eventsPending() { return false; }

uint64_t Vrv32_top::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vrv32_top::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vrv32_top___024root___eval_final(Vrv32_top___024root* vlSelf);

VL_ATTR_COLD void Vrv32_top::final() {
    contextp()->executingFinal(true);
    Vrv32_top___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vrv32_top::hierName() const { return vlSymsp->name(); }
const char* Vrv32_top::modelName() const { return "Vrv32_top"; }
unsigned Vrv32_top::threads() const { return 1; }
void Vrv32_top::prepareClone() const { contextp()->prepareClone(); }
void Vrv32_top::atClone() const {
    contextp()->threadPoolpOnClone();
}
