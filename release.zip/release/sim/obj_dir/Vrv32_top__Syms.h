// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VRV32_TOP__SYMS_H_
#define VERILATED_VRV32_TOP__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vrv32_top.h"

// INCLUDE MODULE CLASSES
#include "Vrv32_top___024root.h"
#include "Vrv32_top___024unit.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) Vrv32_top__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vrv32_top* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vrv32_top___024root            TOP;

    // CONSTRUCTORS
    Vrv32_top__Syms(VerilatedContext* contextp, const char* namep, Vrv32_top* modelp);
    ~Vrv32_top__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
