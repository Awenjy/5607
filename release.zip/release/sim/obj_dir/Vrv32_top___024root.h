// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrv32_top.h for the primary calling header

#ifndef VERILATED_VRV32_TOP___024ROOT_H_
#define VERILATED_VRV32_TOP___024ROOT_H_  // guard

#include "verilated.h"


class Vrv32_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrv32_top___024root final {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(i_clk,0,0);
    VL_IN8(i_rst_n,0,0);
    VL_OUT8(o_halted,0,0);
    VL_OUT8(o_microcode_active,0,0);
    VL_OUT8(o_insns_retired,1,0);
    VL_OUT8(o_imem_re,0,0);
    VL_OUT8(o_dmem_we,3,0);
    VL_OUT8(o_dmem_re,0,0);
    VL_OUT16(o_upc,15,0);
    VL_OUT(o_pc,31,0);
    VL_OUT(o_imem_addr,31,0);
    VL_OUT(o_dmem_addr,31,0);
    VL_OUT(o_dmem_wdata,31,0);
    VL_IN(i_dmem_rdata,31,0);
    VL_IN64(i_imem_rdata,63,0);
    VlUnpacked<IData/*31:0*/, 32> o_debug_regs;

    // INTERNAL VARIABLES
    Vrv32_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vrv32_top___024root(Vrv32_top__Syms* symsp, const char* namep);
    ~Vrv32_top___024root();
    VL_UNCOPYABLE(Vrv32_top___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
