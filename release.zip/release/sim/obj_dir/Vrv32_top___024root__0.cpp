// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vrv32_top.h for the primary calling header

#include "Vrv32_top__pch.h"

void Vrv32_top___024root___eval(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
void Vrv32_top___024root___eval_debug_assertions(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval_debug_assertions\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.i_clk & 0xfeU)))) {
        Verilated::overWidthError("i_clk");
    }
    if (VL_UNLIKELY(((vlSelfRef.i_rst_n & 0xfeU)))) {
        Verilated::overWidthError("i_rst_n");
    }
}
#endif  // VL_DEBUG
