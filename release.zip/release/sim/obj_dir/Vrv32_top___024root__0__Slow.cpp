// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vrv32_top.h for the primary calling header

#include "Vrv32_top__pch.h"

VL_ATTR_COLD void Vrv32_top___024root___eval_static(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval_static\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vrv32_top___024root___eval_initial(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval_initial\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_initial__TOP
        vlSelfRef.o_debug_regs[0U] = 0U;
        vlSelfRef.o_debug_regs[1U] = 0U;
        vlSelfRef.o_debug_regs[2U] = 0U;
        vlSelfRef.o_debug_regs[3U] = 0U;
        vlSelfRef.o_debug_regs[4U] = 0U;
        vlSelfRef.o_debug_regs[5U] = 0U;
        vlSelfRef.o_debug_regs[6U] = 0U;
        vlSelfRef.o_debug_regs[7U] = 0U;
        vlSelfRef.o_debug_regs[8U] = 0U;
        vlSelfRef.o_debug_regs[9U] = 0U;
        vlSelfRef.o_debug_regs[10U] = 0U;
        vlSelfRef.o_debug_regs[11U] = 0U;
        vlSelfRef.o_debug_regs[12U] = 0U;
        vlSelfRef.o_debug_regs[13U] = 0U;
        vlSelfRef.o_debug_regs[14U] = 0U;
        vlSelfRef.o_debug_regs[15U] = 0U;
        vlSelfRef.o_debug_regs[16U] = 0U;
        vlSelfRef.o_debug_regs[17U] = 0U;
        vlSelfRef.o_debug_regs[18U] = 0U;
        vlSelfRef.o_debug_regs[19U] = 0U;
        vlSelfRef.o_debug_regs[20U] = 0U;
        vlSelfRef.o_debug_regs[21U] = 0U;
        vlSelfRef.o_debug_regs[22U] = 0U;
        vlSelfRef.o_debug_regs[23U] = 0U;
        vlSelfRef.o_debug_regs[24U] = 0U;
        vlSelfRef.o_debug_regs[25U] = 0U;
        vlSelfRef.o_debug_regs[26U] = 0U;
        vlSelfRef.o_debug_regs[27U] = 0U;
        vlSelfRef.o_debug_regs[28U] = 0U;
        vlSelfRef.o_debug_regs[29U] = 0U;
        vlSelfRef.o_debug_regs[30U] = 0U;
        vlSelfRef.o_debug_regs[31U] = 0U;
        vlSelfRef.o_pc = 0U;
        vlSelfRef.o_halted = 0U;
        vlSelfRef.o_microcode_active = 0U;
        vlSelfRef.o_upc = 0U;
        vlSelfRef.o_insns_retired = 0U;
        vlSelfRef.o_imem_addr = 0U;
        vlSelfRef.o_imem_re = 0U;
        vlSelfRef.o_dmem_addr = 0U;
        vlSelfRef.o_dmem_wdata = 0U;
        vlSelfRef.o_dmem_we = 0U;
        vlSelfRef.o_dmem_re = 0U;
    }
}

VL_ATTR_COLD void Vrv32_top___024root___eval_final(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval_final\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vrv32_top___024root___eval_settle(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___eval_settle\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vrv32_top___024root___ctor_var_reset(Vrv32_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vrv32_top___024root___ctor_var_reset\n"); );
    Vrv32_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->i_clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15925868812496733354ull);
    vlSelf->i_rst_n = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4084054307081237675ull);
    vlSelf->o_pc = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 11158079901618717280ull);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->o_debug_regs[__Vi0] = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 7123970126263372917ull);
    }
    vlSelf->o_halted = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6448513064632069101ull);
    vlSelf->o_microcode_active = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12378612721294555572ull);
    vlSelf->o_upc = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 17999159751761713347ull);
    vlSelf->o_insns_retired = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 3544621481198256584ull);
    vlSelf->o_imem_addr = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2623029795882035085ull);
    vlSelf->i_imem_rdata = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 11521664675351583267ull);
    vlSelf->o_imem_re = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12830793051373212481ull);
    vlSelf->o_dmem_addr = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 274581538545503949ull);
    vlSelf->o_dmem_wdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12607450708364042141ull);
    vlSelf->i_dmem_rdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 18272911861978324434ull);
    vlSelf->o_dmem_we = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 15716816031960308391ull);
    vlSelf->o_dmem_re = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16930353517694094050ull);
}
