// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vrv32_top.h for the primary calling header

#ifndef VERILATED_VRV32_TOP___024UNIT_H_
#define VERILATED_VRV32_TOP___024UNIT_H_  // guard

#include "verilated.h"


class Vrv32_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vrv32_top___024unit final {
  public:

    // INTERNAL VARIABLES
    Vrv32_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vrv32_top___024unit();
    ~Vrv32_top___024unit();
    void ctor(Vrv32_top__Syms* symsp, const char* namep);
    void dtor();
    VL_UNCOPYABLE(Vrv32_top___024unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
