// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vrv32_top.h for the primary calling header

#include "Vrv32_top__pch.h"


Vrv32_top___024unit::Vrv32_top___024unit() = default;
Vrv32_top___024unit::~Vrv32_top___024unit() = default;

void Vrv32_top___024unit::ctor(Vrv32_top__Syms* symsp, const char* namep) {
    vlSymsp = symsp;
    vlNamep = strdup(Verilated::catName(vlSymsp->name(), namep));
    // Reset structure values
}

void Vrv32_top___024unit::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

void Vrv32_top___024unit::dtor() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}
