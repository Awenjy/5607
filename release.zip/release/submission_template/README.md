# Lab 1 Submission — [Your Name]

**Student ID**: [Your Student ID]
**Date**: [Submission Date]

## AI Tools Declaration

| Tool | Version | Used For |
|:---|:---|:---|
| [e.g., ChatGPT] | [e.g., GPT-4o] | [e.g., RTL generation, debugging] |
| [e.g., Claude] | [e.g., 3.5 Sonnet] | [e.g., C model help] |

## Self-Assessment

- [ ] Part A: All questions answered with work shown
- [ ] Part B: C model compiles and passes all tests
- [ ] Part C: RTL compiles with Verilator and passes co-simulation
- [ ] Part D: (Optional) Yosys synthesis completed
- [ ] LLM prompts documented in `part_c/llm_prompts.md`
- [ ] Performance report in `perf_report.md`
