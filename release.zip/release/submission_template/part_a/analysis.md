# Part A: Quantitative Analysis

## Question A.1: Iron Law CPI Analysis

### (a) Single-Issue Weighted CPI

[Show your calculation here]

### (b) Dual-Issue Weighted CPI

[Show your calculation here]

### (c) Speedup Analysis

[Show your calculation here]

---

## Question A.2: Amdahl's Law and Microcode

### (a) Maximum Speedup from Hardwired Multiplier

[Show your calculation here]

### (b) Net Speedup with 15% Clock Penalty

[Show your calculation here]

### (c) Combined Speedup (Multiplier + Pipelined Divider)

[Show your calculation here]

---

## Question A.3: Pipeline Hazard Stall Analysis

### (a) Cycle-by-Cycle Issue Analysis

| Cycle | Slot 0 | Slot 1 | Notes |
|:---:|:---|:---|:---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| ... | | | |

### (b) Actual CPI

[Show your calculation here]

---

## Question A.4: AMAT and Memory Hierarchy

### (a) AMAT for Instruction Fetches

[Show your calculation here]

### (b) AMAT for Data Accesses

[Show your calculation here]

### (c) Effective Average Memory Penalty per Instruction

[Show your calculation here]
