# LLM Usage Documentation — Part C: RTL Generation

## LLM(s) Used

| LLM | Model/Version | Access Method |
|:---|:---|:---|
| [e.g., ChatGPT] | [e.g., GPT-4o, 2024-08] | [Web / API / IDE Plugin] |

## Iteration Summary

| Iteration | What I Prompted | What Worked | What Didn't | Fix Applied |
|:---:|:---|:---|:---|:---|
| 1 | | | | |
| 2 | | | | |
| ... | | | | |

**Total iterations to first successful Verilator compilation**: ___
**Total iterations to first co-sim test pass**: ___
**Total iterations to all co-sim tests pass**: ___

## Key Prompts

### Prompt 1: [Brief Description]

```
[Paste your prompt here]
```

**Result**: [What the LLM generated, whether it worked]

### Prompt 2: [Brief Description]

```
[Paste your prompt here]
```

**Result**: [What the LLM generated, whether it worked]

[Add more prompts as needed...]

## Common LLM Mistakes Observed

1. [Describe mistake type and frequency]
2. [...]

## Assessment

### What the LLM did well:
- [...]

### What the LLM struggled with:
- [...]

### Lessons learned:
- [...]
