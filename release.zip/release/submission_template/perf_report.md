# Performance Report

## Performance Summary

```
[Paste your ./rv32_sim --stats output here for test_mixed_workload]
```

## CPI Analysis

| Test Program | Cycles | Instructions | CPI | Dual-Issue Rate |
|:---|:---:|:---:|:---:|:---:|
| test_alu_basic | | | | |
| test_load_store | | | | |
| test_branch | | | | |
| test_hazard_raw | | | | |
| test_hazard_dual | | | | |
| test_microcode_mul | | | | |
| test_microcode_div | | | | |
| test_mixed_workload | | | | |
| test_fibonacci | | | | |

## Stall Breakdown Analysis

[Analyze which stall types dominate and why]

## Dual-Issue Effectiveness

[Discuss what fraction of cycles achieve dual-issue and what limits it]

## Microcode Impact

[Quantify the performance cost of microcoded MUL/DIV]

## Comparison to Part A Back-of-Envelope

[Compare your simulated CPI to your Part A analytical predictions]
