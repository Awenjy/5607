/*
 * syscalls.c — Minimal Syscall Stubs for Bare-Metal RV32 Tests
 *
 * Advanced Computer Architecture Lab 1 (CityU EE5607)
 */

#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#undef errno
extern int errno;

/* To-host communication address for simulator termination */
volatile uint32_t tohost __attribute__((section(".tohost"))) = 0;

void _exit(int status) {
    /* Write exit code with LSB=1 to signal termination: (status << 1) | 1 */
    tohost = (status << 1) | 1;
    while (1) {
        __asm__ volatile ("wfi");
    }
}

int _close(int file) {
    (void)file;
    return -1;
}

int _fstat(int file, struct stat *st) {
    (void)file;
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int file) {
    (void)file;
    return 1;
}

int _lseek(int file, int ptr, int dir) {
    (void)file;
    (void)ptr;
    (void)dir;
    return 0;
}

int _read(int file, char *ptr, int len) {
    (void)file;
    (void)ptr;
    (void)len;
    return 0;
}

int _write(int file, char *ptr, int len) {
    (void)file;
    /* In bare-metal simulation, character output can be trapped via MMIO or ignored */
    for (int i = 0; i < len; i++) {
        /* Optional: write to a simple console UART MMIO address if supported */
    }
    return len;
}

void *_sbrk(ptrdiff_t incr) {
    extern char _end; /* Defined by linker */
    static char *heap_end;
    char *prev_heap_end;

    if (heap_end == 0) {
        heap_end = &_end;
    }
    prev_heap_end = heap_end;
    heap_end += incr;
    return (void *)prev_heap_end;
}
